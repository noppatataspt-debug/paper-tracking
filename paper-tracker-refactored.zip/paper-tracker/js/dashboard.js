/* ============================================================
   Paper Tracker — Dashboard Page Logic
   Used by: dashboard.html
   
   Scope: Login, Trace, Lot Lookup, Invoice, History,
          Edit Data, Stats, Access Log
   ============================================================ */

import { supabase } from './config.js';

// ==================== AUTH CONFIG ====================
const DASHBOARD_PASSWORD = 'rptasia';
const MAX_ATTEMPTS = 3;
const LOCKOUT_MINUTES = 5;

// Fetch client IP (best-effort, from public IP API)
async function getClientIP() {
  try {
    const res = await fetch('https://api.ipify.org?format=json');
    const data = await res.json();
    return data.ip || 'unknown';
  } catch (e) {
    return 'unknown';
  }
}

async function logAccess(success, note) {
  try {
    const ip = await getClientIP();
    await supabase.from('dashboard_access_logs').insert({
      ip_address: ip,
      user_agent: navigator.userAgent.substring(0, 200),
      success: success,
      note: note || null
    });
    return ip;
  } catch (e) {
    console.warn('Failed to log access', e);
    return null;
  }
}

// Check if current IP is locked out by counting recent failed attempts
async function checkLockout() {
  try {
    const ip = await getClientIP();
    const sinceTime = new Date(Date.now() - LOCKOUT_MINUTES * 60 * 1000).toISOString();

    const { data, error } = await supabase
      .from('dashboard_access_logs')
      .select('accessed_at, success')
      .eq('ip_address', ip)
      .gte('accessed_at', sinceTime)
      .order('accessed_at', { ascending: false })
      .limit(20);

    if (error) return { locked: false };

    // Look for any successful login in lockout window — if found, count fails AFTER that success
    let failsInWindow = 0;
    let oldestFailTime = null;
    for (const log of data) {
      if (log.success) break; // reset count on any success
      failsInWindow++;
      oldestFailTime = log.accessed_at;
    }

    if (failsInWindow >= MAX_ATTEMPTS) {
      // Find the 3rd failed attempt (the one that triggered lock)
      const thirdFail = data[MAX_ATTEMPTS - 1];
      const lockUntil = new Date(new Date(thirdFail.accessed_at).getTime() + LOCKOUT_MINUTES * 60 * 1000);
      const now = new Date();
      if (lockUntil > now) {
        return {
          locked: true,
          until: lockUntil,
          secondsLeft: Math.ceil((lockUntil - now) / 1000)
        };
      }
    }
    return { locked: false, failCount: failsInWindow };
  } catch (e) {
    console.warn('Check lockout failed', e);
    return { locked: false };
  }
}

// ==================== LOGIN HANDLING ====================
const loginScreen = document.getElementById('login-screen');
const loginInput = document.getElementById('login-input');
const loginBtn = document.getElementById('login-btn');
const loginError = document.getElementById('login-error');
const mainContainer = document.getElementById('main-container');

let lockoutTimer = null;

function startLockoutCountdown(secondsLeft) {
  loginInput.disabled = true;
  loginBtn.disabled = true;
  clearInterval(lockoutTimer);

  function tick() {
    if (secondsLeft <= 0) {
      clearInterval(lockoutTimer);
      loginInput.disabled = false;
      loginBtn.disabled = false;
      loginBtn.textContent = 'เข้าสู่ระบบ';
      loginError.textContent = '';
      loginInput.focus();
      return;
    }
    const m = Math.floor(secondsLeft / 60);
    const s = secondsLeft % 60;
    const timeStr = m > 0 ? `${m} นาที ${s} วิ` : `${s} วินาที`;
    loginBtn.textContent = `🔒 ถูกล็อก รออีก ${timeStr}`;
    loginError.textContent = `พยายามเข้าผิด ${MAX_ATTEMPTS} ครั้ง — ระบบล็อกชั่วคราว`;
    secondsLeft--;
  }
  tick();
  lockoutTimer = setInterval(tick, 1000);
}

async function doLogin() {
  const val = loginInput.value.trim();
  if (!val) {
    loginInput.focus();
    return;
  }

  loginBtn.disabled = true;
  loginBtn.textContent = 'กำลังตรวจสอบ...';
  loginError.textContent = '';

  // Check lockout first (prevent bypass via refresh)
  const lockStatus = await checkLockout();
  if (lockStatus.locked) {
    startLockoutCountdown(lockStatus.secondsLeft);
    await logAccess(false, `Blocked: still in lockout (${lockStatus.secondsLeft}s left)`);
    return;
  }

  if (val === DASHBOARD_PASSWORD) {
    // Success
    await logAccess(true, 'Login success');
    loginScreen.style.display = 'none';
    mainContainer.style.display = 'block';
    initDashboard();
  } else {
    // Failed
    const failCount = (lockStatus.failCount || 0) + 1;
    await logAccess(false, `Wrong password (attempt ${failCount}/${MAX_ATTEMPTS})`);

    loginInput.classList.add('shake');
    loginInput.value = '';
    setTimeout(() => loginInput.classList.remove('shake'), 500);

    if (failCount >= MAX_ATTEMPTS) {
      // Start lockout
      startLockoutCountdown(LOCKOUT_MINUTES * 60);
    } else {
      loginError.textContent = `รหัสไม่ถูกต้อง (${failCount}/${MAX_ATTEMPTS}) — ผิด ${MAX_ATTEMPTS} ครั้งจะถูกล็อก ${LOCKOUT_MINUTES} นาที`;
      loginBtn.disabled = false;
      loginBtn.textContent = 'เข้าสู่ระบบ';
      loginInput.focus();
    }
  }
}

loginBtn.addEventListener('click', doLogin);
loginInput.addEventListener('keydown', e => {
  if (e.key === 'Enter' && !loginInput.disabled) doLogin();
});
document.getElementById('btn-logout').addEventListener('click', () => {
  if (confirm('ต้องการออกจากระบบ?')) {
    location.reload();
  }
});

// Check lockout on page load (in case user refreshed during lockout)
(async () => {
  const lockStatus = await checkLockout();
  if (lockStatus.locked) {
    startLockoutCountdown(lockStatus.secondsLeft);
  } else {
    setTimeout(() => loginInput.focus(), 100);
  }
})();

// ==================== UTILS ====================

function escapeHtml(s) {
  if (s == null) return '';
  return String(s).replace(/[&<>"']/g, c =>
    ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
}

function setConnStatus(online, label) {
  const el = document.getElementById('conn-status');
  el.classList.toggle('online', online);
  el.classList.toggle('offline', !online);
  document.getElementById('conn-label').textContent = label;
}

// ==================== CSV EXPORT ====================

function csvEscape(val) {
  if (val == null) return '';
  const s = String(val);
  // ถ้ามี comma, quote, newline ต้อง wrap ด้วย quotes และ escape quotes
  if (/[",\n\r]/.test(s)) {
    return '"' + s.replace(/"/g, '""') + '"';
  }
  return s;
}

function rowsToCSV(headers, rows) {
  const lines = [headers.map(csvEscape).join(',')];
  rows.forEach(r => lines.push(r.map(csvEscape).join(',')));
  return lines.join('\r\n');
}

function downloadCSV(csv, filename) {
  // Add BOM for Excel UTF-8 compatibility (ให้ภาษาไทยไม่เพี้ยน)
  const BOM = '\uFEFF';
  const blob = new Blob([BOM + csv], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

// Format YYYYMMDD_HHmmss สำหรับ filename
function timestamp() {
  const d = new Date();
  const pad = n => String(n).padStart(2, '0');
  return `${d.getFullYear()}${pad(d.getMonth()+1)}${pad(d.getDate())}_${pad(d.getHours())}${pad(d.getMinutes())}${pad(d.getSeconds())}`;
}

// แปลง scan record เป็น CSV row (ตรงกับ format เดิมของบริษัท + field ใหม่)
function scanToRow(s) {
  // วันที่ผลิตแบบ ว-ด-ป (DD-MM-YY)
  const prodDate = s.production_date
    ? (() => {
        const [y, m, d] = s.production_date.split('-');
        return `${d}-${m}-${y.slice(2)}`;
      })()
    : '';

  return [
    s.barcode_raw || '',
    prodDate,
    s.machine_name || '',
    s.product_name || '',
    s.paper_type || '',
    s.cut_date || '',
    s.roll_no || '',
    s.slitter || '',
    s.jumbo_lot || '',
    s.is_new_product ? 'ใช่' : '',
    s.barcode_valid === false ? 'ผิด' : '',
    s.barcode_warnings || '',
    s.scanned_at ? new Date(s.scanned_at).toLocaleString('th-TH') : ''
  ];
}

const SCAN_CSV_HEADERS = [
  'Barcode',
  'วันที่ใช้ (ว-ด-ป)',
  'เครื่องที่ผลิต',
  'สินค้า',
  'ประเภทกระดาษ',
  'วันที่ตัดกระดาษ',
  'ม้วนที่',
  'Slitter',
  'ล็อตจัมโบ้',
  'สินค้าใหม่?',
  'Barcode ผิด?',
  'หมายเหตุ Barcode',
  'เวลาที่สแกน'
];

// ==================== BATCH DETAIL MODAL ====================
async function openBatchDetail(batchId) {
  const modal = document.getElementById('detail-modal');
  const body = document.getElementById('detail-body');
  modal.classList.add('show');
  body.innerHTML = '<div class="loading"><div class="spinner-small"></div><div style="margin-top:10px;">กำลังโหลด...</div></div>';

  try {
    // Load batch + join data
    const { data: batch, error: bErr } = await supabase
      .from('production_batches')
      .select(`
        id, production_date, submitted_at, voided, voided_reason,
        machines (name, dp),
        batch_products (id, product_name, is_new_product, sequence)
      `)
      .eq('id', batchId)
      .single();
    if (bErr) throw bErr;

    const { data: scans, error: sErr } = await supabase
      .from('paper_scans')
      .select('*')
      .eq('batch_id', batchId)
      .order('scanned_at', { ascending: true });
    if (sErr) throw sErr;

    // ดึง invoice info สำหรับ lots ใน batch นี้
    const uniqueLots = [...new Set(scans.map(s => (s.jumbo_lot || '').replace(/-/g, '').toUpperCase()).filter(x => x))];
    let invoiceMap = {};
    if (uniqueLots.length > 0) {
      const { data: invData } = await supabase
        .from('paper_invoices')
        .select('paper_lot, paper_lot_normalized, invoice_no, supplier, receive_date, weight_kg, price_per_roll')
        .in('paper_lot_normalized', uniqueLots);
      (invData || []).forEach(inv => {
        invoiceMap[inv.paper_lot_normalized] = inv;
      });
    }

    renderBatchDetail(batch, scans, invoiceMap);
  } catch (err) {
    console.error(err);
    body.innerHTML = `<div class="empty"><span class="emoji">⚠️</span><div class="empty-title">โหลดไม่สำเร็จ</div><div>${escapeHtml(err.message)}</div></div>`;
  }
}

function renderBatchDetail(batch, scans, invoiceMap) {
  invoiceMap = invoiceMap || {};
  document.getElementById('detail-title').innerHTML =
    `📋 Batch · ${batch.production_date} · ${escapeHtml(batch.machines?.name || '-')}` +
    (batch.voided ? ' <span class="voided-badge">ยกเลิกแล้ว</span>' : '');
  document.getElementById('detail-subtitle').textContent =
    `บันทึกเมื่อ ${new Date(batch.submitted_at).toLocaleString('th-TH')}` +
    (batch.voided ? ` · เหตุผลที่ยกเลิก: ${batch.voided_reason || '-'}` : '');

  const products = (batch.batch_products || []).sort((a, b) => a.sequence - b.sequence);

  // Group scans by product
  const byProduct = {};
  products.forEach(p => byProduct[p.id] = { product: p, scans: [] });
  scans.forEach(s => {
    if (byProduct[s.batch_product_id]) byProduct[s.batch_product_id].scans.push(s);
  });

  // Stats
  const totalScans = scans.length;
  const uniqueBarcodes = new Set(scans.map(s => s.barcode_raw)).size;
  const hasSharedRolls = uniqueBarcodes < totalScans;
  const invalidCount = scans.filter(s => s.barcode_valid === false).length;
  const uniqueLots = new Set(scans.map(s => s.jumbo_lot)).size;
  const uniqueTypes = new Set(scans.map(s => s.paper_type)).size;
  
  // Invoice stats
  const lotsWithInvoice = [...new Set(scans.map(s => (s.jumbo_lot || '').replace(/-/g, '').toUpperCase()))].filter(l => invoiceMap[l]);
  const uniqueSuppliers = new Set(Object.values(invoiceMap).map(i => i.supplier).filter(x => x));

  // หาม้วนที่ share กัน (barcode ถูก scan หลายครั้งใน batch เดียวกัน)
  const barcodeUsage = {};
  scans.forEach(s => {
    if (!barcodeUsage[s.barcode_raw]) barcodeUsage[s.barcode_raw] = new Set();
    barcodeUsage[s.barcode_raw].add(s.batch_product_id);
  });
  const sharedBarcodes = Object.entries(barcodeUsage).filter(([_, products]) => products.size > 1);

  let html = `<div class="detail-stats">
    <div class="detail-stat">
      <div class="detail-stat-label">สินค้า</div>
      <div class="detail-stat-value">${products.length}</div>
    </div>
    <div class="detail-stat">
      <div class="detail-stat-label">ม้วนกระดาษ</div>
      <div class="detail-stat-value" style="color:var(--accent);">${uniqueBarcodes}</div>
      ${hasSharedRolls ? `<div style="font-size:10px;color:var(--text-dim);margin-top:2px;">(${totalScans} รายการ)</div>` : ''}
    </div>
    <div class="detail-stat">
      <div class="detail-stat-label">Jumbo Lots</div>
      <div class="detail-stat-value" style="color:var(--accent-2);">${uniqueLots}</div>
    </div>
    <div class="detail-stat">
      <div class="detail-stat-label">📄 Invoice</div>
      <div class="detail-stat-value" style="color:#4338ca;">${lotsWithInvoice.length}/${uniqueLots}</div>
      ${uniqueSuppliers.size > 0 ? `<div style="font-size:10px;color:var(--text-dim);margin-top:2px;">${[...uniqueSuppliers].join(', ')}</div>` : ''}
    </div>
  </div>`;

  if (hasSharedRolls) {
    html += `<div style="padding:10px 14px;background:var(--accent-2-bg);border-left:4px solid var(--accent-2);border-radius:8px;margin-bottom:12px;font-size:13px;color:#1e3a8a;">
      🔗 <strong>มี ${sharedBarcodes.length} ม้วนที่ใช้ร่วมหลายสินค้า</strong> (บันทึกซ้ำในแต่ละสินค้า)
    </div>`;
  }

  if (invalidCount > 0) {
    html += `<div style="padding:10px 14px;background:#fef3c7;border-left:4px solid #d97706;border-radius:8px;margin-bottom:12px;font-size:13px;color:#78350f;">
      ⚠️ มี ${invalidCount} Barcode ผิด format ใน batch นี้
    </div>`;
  }

  // ==================== SUMMARY SECTIONS (ใหม่) ====================
  // คำนวณ unique rolls (ไม่นับซ้ำที่เกิดจาก shared)
  const uniqueRollScans = [...new Map(scans.map(s => [s.barcode_raw, s])).values()];

  // 1. Paper Type Breakdown
  const byType = {};
  uniqueRollScans.forEach(s => {
    const t = s.paper_type || '(ไม่ระบุ)';
    byType[t] = (byType[t] || 0) + 1;
  });
  const typeEntries = Object.entries(byType).sort((a, b) => b[1] - a[1]);
  const totalUniq = uniqueRollScans.length;

  // 2. Supplier Breakdown
  const bySupplier = {};
  uniqueRollScans.forEach(s => {
    const norm = (s.jumbo_lot || '').replace(/-/g, '').toUpperCase();
    const sup = invoiceMap[norm]?.supplier || '(ไม่ทราบ)';
    bySupplier[sup] = (bySupplier[sup] || 0) + 1;
  });
  const supEntries = Object.entries(bySupplier).sort((a, b) => b[1] - a[1]);

  // 3. Lot Summary (group by lot)
  const byLot = {};
  uniqueRollScans.forEach(s => {
    const lot = s.jumbo_lot || '(ไม่ระบุ)';
    if (!byLot[lot]) {
      const norm = lot.replace(/-/g, '').toUpperCase();
      byLot[lot] = { lot, paper_type: s.paper_type, count: 0, invoice: invoiceMap[norm] };
    }
    byLot[lot].count++;
  });
  const lotEntries = Object.values(byLot).sort((a, b) => b.count - a.count);

  // --- Render Paper Type bar ---
  html += `<div class="detail-summary-section">
    <div class="detail-summary-title">📦 ประเภทกระดาษที่ใช้</div>
    <div class="detail-summary-body">`;
  typeEntries.forEach(([type, cnt]) => {
    const pct = (cnt / totalUniq * 100).toFixed(0);
    html += `<div class="detail-bar-row">
      <div class="detail-bar-label">${escapeHtml(type)}</div>
      <div class="detail-bar-track">
        <div class="detail-bar-fill" style="width:${pct}%;background:var(--accent,#6366f1);"></div>
      </div>
      <div class="detail-bar-value">${cnt} ม้วน <span style="color:var(--text-dim);font-weight:400;">(${pct}%)</span></div>
    </div>`;
  });
  html += `</div></div>`;

  // --- Render Supplier bar ---
  html += `<div class="detail-summary-section">
    <div class="detail-summary-title">🏭 Supplier</div>
    <div class="detail-summary-body">`;
  supEntries.forEach(([sup, cnt]) => {
    const pct = (cnt / totalUniq * 100).toFixed(0);
    const barColor = sup === '(ไม่ทราบ)' ? '#94a3b8' : '#4338ca';
    html += `<div class="detail-bar-row">
      <div class="detail-bar-label">${sup !== '(ไม่ทราบ)' ? '📄 ' : '❓ '}${escapeHtml(sup)}</div>
      <div class="detail-bar-track">
        <div class="detail-bar-fill" style="width:${pct}%;background:${barColor};"></div>
      </div>
      <div class="detail-bar-value">${cnt} ม้วน <span style="color:var(--text-dim);font-weight:400;">(${pct}%)</span></div>
    </div>`;
  });
  html += `</div></div>`;

  // --- Render Lot Summary ---
  html += `<div class="detail-summary-section">
    <div class="detail-summary-title">📋 Jumbo Lots ที่ใช้ (${lotEntries.length} lots)</div>
    <div class="detail-summary-body">
      <table class="detail-lot-table">
        <thead>
          <tr><th>Jumbo Lot</th><th>ประเภท</th><th>Supplier</th><th>Invoice</th><th>วันรับเข้า</th><th style="text-align:right;">จำนวน</th></tr>
        </thead>
        <tbody>`;
  lotEntries.forEach(lg => {
    const inv = lg.invoice;
    html += `<tr>
      <td><strong>${escapeHtml(lg.lot)}</strong></td>
      <td>${escapeHtml(lg.paper_type || '-')}</td>
      <td>${inv ? `<span style="padding:1px 7px;background:#eef2ff;color:#4338ca;border-radius:4px;font-size:11px;font-weight:600;">${escapeHtml(inv.supplier || '-')}</span>` : '<span style="color:var(--text-dim);">?</span>'}</td>
      <td style="font-size:12px;">${inv?.invoice_no ? escapeHtml(inv.invoice_no) : '-'}</td>
      <td style="font-size:12px;color:var(--text-dim);">${inv?.receive_date || '-'}</td>
      <td style="text-align:right;font-weight:700;">${lg.count} ม้วน</td>
    </tr>`;
  });
  html += `</tbody></table></div></div>`;

  // --- Toggle button สำหรับ scan list ---
  html += `<div style="margin:16px 0 8px;">
    <button class="btn btn-ghost" id="toggle-scan-list" style="width:100%;">
      📝 แสดงรายการ Barcode ทั้งหมด (${totalScans} รายการ) ▼
    </button>
  </div>
  <div id="scan-list-container" style="display:none;">`;

  // Render each product group (เดิม)
  Object.values(byProduct).forEach(({ product, scans: prodScans }) => {
    html += `<div class="detail-product-group">
      <div class="detail-product-header">
        <div class="detail-product-name">
          📦 ${escapeHtml(product.product_name)}
          ${product.is_new_product ? '<span style="font-size:10px;padding:2px 6px;background:var(--accent-2);color:white;border-radius:4px;margin-left:6px;">ใหม่</span>' : ''}
        </div>
        <div class="detail-product-count">${prodScans.length} ม้วน</div>
      </div>`;
    prodScans.forEach((s, idx) => {
      const t = new Date(s.scanned_at).toLocaleTimeString('th-TH', {hour:'2-digit',minute:'2-digit',second:'2-digit'});
      // Check if this barcode is shared with other products
      const sharedWith = barcodeUsage[s.barcode_raw] ? barcodeUsage[s.barcode_raw].size : 1;
      const isShared = sharedWith > 1;
      const sharedBadge = isShared
        ? `<span style="display:inline-block;padding:1px 7px;background:var(--accent-2-bg);color:var(--accent-2);border-radius:4px;font-size:10px;font-weight:700;margin-left:6px;" title="ม้วนนี้ใช้กับ ${sharedWith} สินค้า">🔗 ใช้ร่วม ×${sharedWith}</span>`
        : '';
      
      // Invoice badge
      const lotNorm = (s.jumbo_lot || '').replace(/-/g, '').toUpperCase();
      const inv = invoiceMap[lotNorm];
      const invBadge = inv
        ? `<span style="display:inline-block;padding:1px 7px;background:#eef2ff;color:#4338ca;border-radius:4px;font-size:10px;font-weight:600;margin-left:6px;" title="Invoice: ${escapeHtml(inv.invoice_no || '-')} | Supplier: ${escapeHtml(inv.supplier || '-')} | รับเข้า: ${inv.receive_date || '-'}">📄 ${escapeHtml(inv.supplier || '?')}</span>`
        : '';
      
      html += `<div class="detail-scan-row ${s.barcode_valid === false ? 'invalid' : ''}">
        <div class="detail-scan-num">${idx + 1}</div>
        <div class="detail-scan-barcode" title="${escapeHtml(s.barcode_raw || '')}">
          ${escapeHtml(s.barcode_raw || '')}${sharedBadge}${invBadge}
          ${s.barcode_valid === false ? '<span style="color:#d97706;font-size:11px;margin-left:6px;">⚠️ ' + escapeHtml(s.barcode_warnings || '') + '</span>' : ''}
        </div>
        <div class="detail-scan-time">${t}</div>
      </div>`;
    });
    html += `</div>`;
  });

  if (products.length === 0) {
    html += '<div class="empty"><span class="emoji">📭</span><div>ไม่มีข้อมูล</div></div>';
  }

  html += `</div>`;  // close scan-list-container

  document.getElementById('detail-body').innerHTML = html;

  // Toggle scan list
  const toggleBtn = document.getElementById('toggle-scan-list');
  const scanContainer = document.getElementById('scan-list-container');
  if (toggleBtn && scanContainer) {
    toggleBtn.addEventListener('click', () => {
      const isHidden = scanContainer.style.display === 'none';
      scanContainer.style.display = isHidden ? 'block' : 'none';
      toggleBtn.innerHTML = isHidden
        ? `📝 ซ่อนรายการ Barcode (${totalScans} รายการ) ▲`
        : `📝 แสดงรายการ Barcode ทั้งหมด (${totalScans} รายการ) ▼`;
    });
  }

  // Set edit button to open editor with this batch
  const editBtn = document.getElementById('detail-btn-edit');
  editBtn.onclick = () => {
    closeBatchDetail();
    // Switch to edit tab then open editor
    document.querySelectorAll('.tab').forEach(x => x.classList.remove('active'));
    document.querySelectorAll('.view').forEach(x => x.classList.remove('active'));
    document.querySelector('.tab[data-view="edit"]').classList.add('active');
    document.getElementById('view-edit').classList.add('active');
    openEditor(batch.id);
  };
}

function closeBatchDetail() {
  document.getElementById('detail-modal').classList.remove('show');
}

document.getElementById('detail-close').addEventListener('click', closeBatchDetail);
document.getElementById('detail-btn-close').addEventListener('click', closeBatchDetail);
document.getElementById('detail-modal').addEventListener('click', e => {
  if (e.target.id === 'detail-modal') closeBatchDetail();
});
document.addEventListener('keydown', e => {
  if (e.key === 'Escape' && document.getElementById('detail-modal').classList.contains('show')) {
    closeBatchDetail();
  }
});

// ==================== TABS ====================
document.querySelectorAll('.tab').forEach(t => {
  t.addEventListener('click', () => {
    document.querySelectorAll('.tab').forEach(x => x.classList.remove('active'));
    document.querySelectorAll('.view').forEach(x => x.classList.remove('active'));
    t.classList.add('active');
    document.getElementById('view-' + t.dataset.view).classList.add('active');
    if (t.dataset.view === 'history' && !window._historyAutoLoaded) {
      window._historyAutoLoaded = true;
      loadHistory();
    }
    if (t.dataset.view === 'edit' && !window._editAutoLoaded) {
      window._editAutoLoaded = true;
      loadEditList();
    }
    if (t.dataset.view === 'stats' && !window._statsAutoLoaded) {
      window._statsAutoLoaded = true;
      loadStats();
    }
    if (t.dataset.view === 'access') loadAccessLog();
  });
});

// ==================== LOAD MASTER ====================
async function loadMaster() {
  try {
    const [machinesRes, productsRes] = await Promise.all([
      supabase.from('machines').select('id, name, dp').order('dp').order('id'),
      supabase.from('products').select('product_name').eq('is_active', true).order('product_name')
    ]);
    if (machinesRes.error) throw machinesRes.error;
    if (productsRes.error) throw productsRes.error;

    const tMachine = document.getElementById('t-machine');
    const hMachine = document.getElementById('h-machine');
    const eMachine = document.getElementById('e-machine');
    machinesRes.data.forEach(m => {
      const opt = document.createElement('option');
      opt.value = m.id;
      opt.textContent = `${m.name} (${m.dp})`;
      tMachine.appendChild(opt);
      hMachine.appendChild(opt.cloneNode(true));
      eMachine.appendChild(opt.cloneNode(true));
    });

    // Save product list for autocomplete
    window._allProducts = productsRes.data.map(p => p.product_name);
    setupProductAutocomplete();

    setConnStatus(true, `✓ ${machinesRes.data.length} เครื่อง · ${productsRes.data.length} สินค้า`);

    // Default date = today
    document.getElementById('t-date').valueAsDate = new Date();

    // Default history filter: last 30 days
    const today = new Date();
    const thirtyDaysAgo = new Date(today.getTime() - 30 * 24 * 60 * 60 * 1000);
    document.getElementById('h-from').valueAsDate = thirtyDaysAgo;
    document.getElementById('h-to').valueAsDate = today;

    // Edit view: last 7 days by default
    const sevenDaysAgo = new Date(today.getTime() - 7 * 24 * 60 * 60 * 1000);
    document.getElementById('e-from').valueAsDate = sevenDaysAgo;
    document.getElementById('e-to').valueAsDate = today;

    // Stats view: last 30 days by default
    document.getElementById('s-from').valueAsDate = thirtyDaysAgo;
    document.getElementById('s-to').valueAsDate = today;

    // Save global master for editor
    window._masterMachines = machinesRes.data;
    window._masterProducts = (productsRes.data || []).map(r => r.product_name);
  } catch (err) {
    console.error(err);
    setConnStatus(false, '✗ เชื่อมต่อ DB ไม่ได้');
  }
}

// ==================== AUTOCOMPLETE ====================

// Escape regex special chars
function escRegex(s) {
  return String(s).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

// ไฮไลท์ตำแหน่งที่ match ในข้อความ — return innerHTML ปลอดภัย
function highlightMatch(text, query, className) {
  if (!query) return escapeHtml(text);
  const cls = className || 'hit';
  const re = new RegExp('(' + escRegex(query) + ')', 'gi');
  // split แล้ว escape แต่ละ chunk ก่อน ต่อด้วย <span>
  const parts = String(text).split(re);
  return parts.map((p, i) => {
    if (i % 2 === 1) return '<span class="' + cls + '">' + escapeHtml(p) + '</span>';
    return escapeHtml(p);
  }).join('');
}

function setupProductAutocomplete() {
  const input = document.getElementById('t-product-input');
  const hidden = document.getElementById('t-product');
  const box = document.getElementById('t-product-suggest');
  if (!input || !window._allProducts) return;

  let activeIdx = -1;
  let currentMatches = [];

  function render() {
    const q = input.value.trim();
    if (!q) {
      // แสดง top 20 อันดับแรก
      currentMatches = window._allProducts.slice(0, 30);
    } else {
      const qLow = q.toLowerCase();
      // รวม 3 กลุ่ม: startsWith > includes > fuzzy
      const starts = [], contains = [];
      window._allProducts.forEach(p => {
        const pLow = p.toLowerCase();
        if (pLow.startsWith(qLow)) starts.push(p);
        else if (pLow.includes(qLow)) contains.push(p);
      });
      currentMatches = [...starts, ...contains].slice(0, 30);
    }

    if (currentMatches.length === 0) {
      box.innerHTML = '<div class="ac-empty">ไม่พบสินค้า — กด Enter เพื่อค้นทุกสินค้า</div>';
      box.style.display = 'block';
      return;
    }
    box.innerHTML = currentMatches.map((p, i) => {
      const isActive = i === activeIdx;
      return `<div class="ac-item ${isActive ? 'active' : ''}" data-idx="${i}" data-value="${escapeHtml(p)}">${highlightMatch(p, q, 'hit')}</div>`;
    }).join('');
    box.style.display = 'block';

    // Attach click handlers
    box.querySelectorAll('.ac-item').forEach(el => {
      el.addEventListener('mousedown', e => {
        e.preventDefault();  // ป้องกัน blur ก่อน click
        const v = el.dataset.value;
        input.value = v;
        hidden.value = v;
        box.style.display = 'none';
      });
    });
  }

  input.addEventListener('focus', () => {
    activeIdx = -1;
    render();
  });

  input.addEventListener('input', () => {
    hidden.value = input.value.trim();  // sync value
    activeIdx = -1;
    render();
  });

  input.addEventListener('blur', () => {
    // delay เพื่อให้ click event ทำงานก่อน
    setTimeout(() => box.style.display = 'none', 150);
  });

  input.addEventListener('keydown', e => {
    if (box.style.display === 'none') return;
    if (e.key === 'ArrowDown') {
      e.preventDefault();
      activeIdx = Math.min(activeIdx + 1, currentMatches.length - 1);
      render();
      // Scroll into view
      const active = box.querySelector('.ac-item.active');
      if (active) active.scrollIntoView({ block: 'nearest' });
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      activeIdx = Math.max(activeIdx - 1, -1);
      render();
      const active = box.querySelector('.ac-item.active');
      if (active) active.scrollIntoView({ block: 'nearest' });
    } else if (e.key === 'Enter') {
      if (activeIdx >= 0 && activeIdx < currentMatches.length) {
        e.preventDefault();
        const v = currentMatches[activeIdx];
        input.value = v;
        hidden.value = v;
        box.style.display = 'none';
      } else {
        hidden.value = input.value.trim();
        box.style.display = 'none';
        runTrace();
      }
    } else if (e.key === 'Escape') {
      box.style.display = 'none';
    }
  });
}

// ==================== VIEW 1: TRACE ====================
async function runTrace() {
  const date = document.getElementById('t-date').value;
  const machineId = document.getElementById('t-machine').value;
  const product = document.getElementById('t-product').value;

  if (!date) {
    alert('กรุณาเลือกวันที่');
    return;
  }

  const container = document.getElementById('t-result');
  container.innerHTML = '<div class="loading"><div class="spinner-small"></div><div style="margin-top:10px;">กำลังค้นหา...</div></div>';

  try {
    let query = supabase
      .from('v_scan_details')
      .select('*')
      .eq('production_date', date);

    if (machineId) query = query.eq('machine_id', parseInt(machineId));
    if (product) query = query.eq('product_name', product);

    const { data, error } = await query;
    if (error) throw error;

    // โหลด invoice info สำหรับ lots ที่เจอ
    const lotNorms = [...new Set((data || []).map(s => (s.jumbo_lot || '').replace(/-/g, '').toUpperCase()).filter(x => x))];
    let invoiceMap = {};
    if (lotNorms.length > 0) {
      const { data: invData } = await supabase
        .from('paper_invoices')
        .select('paper_lot_normalized, invoice_no, supplier, receive_date, weight_kg, paper_type')
        .in('paper_lot_normalized', lotNorms);
      (invData || []).forEach(inv => {
        invoiceMap[inv.paper_lot_normalized] = inv;
      });
    }

    window._traceData = data;  // เก็บไว้สำหรับ export
    window._traceInvoiceMap = invoiceMap;
    window._traceParams = { date, machineId, product };
    renderTraceResult(container, data, { date, machineId, product }, invoiceMap);
  } catch (err) {
    console.error(err);
    container.innerHTML = `<div class="empty"><span class="emoji">⚠️</span><div class="empty-title">ค้นหาไม่สำเร็จ</div><div>${escapeHtml(err.message)}</div></div>`;
  }
}

function renderTraceResult(container, data, params, invoiceMap) {
  invoiceMap = invoiceMap || {};
  if (!data || data.length === 0) {
    container.innerHTML = '<div class="empty"><span class="emoji">📭</span><div class="empty-title">ไม่พบข้อมูล</div><div>ลองเปลี่ยนเงื่อนไขการค้นหา</div></div>';
    return;
  }

  // Group: product → paper_type → invoice_no → jumbo_lot
  const byProduct = {};
  data.forEach(s => {
    const pkey = s.product_name + '|' + (s.is_new_product ? '1' : '0');
    if (!byProduct[pkey]) byProduct[pkey] = { name: s.product_name, isNew: s.is_new_product, types: {} };
    
    if (!byProduct[pkey].types[s.paper_type]) byProduct[pkey].types[s.paper_type] = {};
    
    // หา invoice จาก normalized lot
    const lotNorm = (s.jumbo_lot || '').replace(/-/g, '').toUpperCase();
    const inv = invoiceMap[lotNorm];
    const invKey = inv?.invoice_no || '__NO_INVOICE__';
    
    if (!byProduct[pkey].types[s.paper_type][invKey]) {
      byProduct[pkey].types[s.paper_type][invKey] = {
        invoice_no: inv?.invoice_no || null,
        supplier: inv?.supplier || null,
        receive_date: inv?.receive_date || null,
        lots: {}
      };
    }
    
    const invGroup = byProduct[pkey].types[s.paper_type][invKey];
    const lotKey = s.jumbo_lot;
    if (!invGroup.lots[lotKey]) {
      invGroup.lots[lotKey] = { count: 0, cut_date: s.cut_date, slitter: s.slitter, machine_name: s.machine_name };
    }
    invGroup.lots[lotKey].count++;
  });

  const totalTypes = new Set(data.map(s => s.paper_type)).size;
  const totalRolls = data.length;
  const uniqueBarcodes = new Set(data.map(s => s.barcode_raw)).size;
  const hasSharedRolls = uniqueBarcodes < totalRolls;
  const totalLots = new Set(data.map(s => s.jumbo_lot)).size;
  const totalProducts = new Set(data.map(s => s.product_name)).size;
  const totalInvoices = new Set(data.map(s => {
    const norm = (s.jumbo_lot || '').replace(/-/g, '').toUpperCase();
    return invoiceMap[norm]?.invoice_no;
  }).filter(x => x)).size;

  let html = `<div class="panel-actions">
    <button class="export-btn" id="btn-export-trace">📥 Export CSV (${totalRolls} rows)</button>
  </div>
  <div class="stats">
    <div class="stat"><div class="stat-label">สินค้า</div><div class="stat-value">${totalProducts}</div></div>
    <div class="stat"><div class="stat-label">ประเภทกระดาษ</div><div class="stat-value blue">${totalTypes}</div></div>
    <div class="stat"><div class="stat-label">Jumbo Lots</div><div class="stat-value accent">${totalLots}</div></div>
    <div class="stat"><div class="stat-label">Invoices</div><div class="stat-value" style="color:#4338ca;">${totalInvoices}</div></div>
    <div class="stat">
      <div class="stat-label">ม้วนกระดาษ</div>
      <div class="stat-value">${uniqueBarcodes}</div>
      ${hasSharedRolls ? `<div style="font-size:11px;color:var(--text-dim);margin-top:2px;">(${totalRolls} รายการ - มีม้วนใช้ร่วม)</div>` : ''}
    </div>
  </div>
  <div id="trace-report-placeholder"></div>`;  // report จะ inject ตรงนี้ ด้านบน product groups

  // Sort products by scan count desc
  const sortedProducts = Object.values(byProduct).sort((a, b) => {
    const sumA = Object.values(a.types).reduce((s, t) => s + Object.values(t).reduce((ss, inv) => ss + Object.values(inv.lots).reduce((sss, v) => sss + v.count, 0), 0), 0);
    const sumB = Object.values(b.types).reduce((s, t) => s + Object.values(t).reduce((ss, inv) => ss + Object.values(inv.lots).reduce((sss, v) => sss + v.count, 0), 0), 0);
    return sumB - sumA;
  });

  html += `<div class="trace-details-section">
    <div class="trace-details-title">📋 รายละเอียดการใช้วัตถุดิบ <span style="font-weight:400;color:var(--text-dim);font-size:12px;">(คลิกที่สินค้าเพื่อขยาย)</span></div>
  </div>`;

  sortedProducts.forEach((prod, prodIdx) => {
    const productTotal = Object.values(prod.types).reduce((s, t) => 
      s + Object.values(t).reduce((ss, inv) => 
        ss + Object.values(inv.lots).reduce((sss, v) => sss + v.count, 0), 0), 0);

    const prodId = 'prod-' + prodIdx;
    // Summary compact line per paper type (สั้น ๆ ให้เห็นเลย ก่อน expand)
    const typeSummary = Object.entries(prod.types).map(([type, invoices]) => {
      const typeTotal = Object.values(invoices).reduce((s, inv) => s + Object.values(inv.lots).reduce((ss, v) => ss + v.count, 0), 0);
      const numInvoices = Object.keys(invoices).length;
      const numLots = Object.values(invoices).reduce((s, inv) => s + Object.keys(inv.lots).length, 0);
      return `<div class="prod-summary-row">
        <span class="prod-summary-type">${escapeHtml(type)}</span>
        <span class="prod-summary-meta">${numInvoices} inv · ${numLots} lots · <strong>${typeTotal} ม้วน</strong></span>
      </div>`;
    }).join('');

    html += `<div class="trace-group collapsible" data-prod-id="${prodId}">
      <div class="trace-group-header clickable" onclick="toggleProdGroup('${prodId}')">
        <div class="trace-group-title">
          <span class="toggle-arrow" id="arrow-${prodId}">▶</span>
          📦 ${escapeHtml(prod.name)}
          ${prod.isNew ? '<span class="new-badge">ใหม่</span>' : ''}
        </div>
        <div class="trace-group-count">${productTotal} ม้วน</div>
      </div>
      <div class="trace-group-summary">${typeSummary}</div>
      <div class="trace-group-details" id="${prodId}" style="display:none;">`;

    // Sort paper types by total count
    const sortedTypes = Object.entries(prod.types).sort((a, b) => {
      const sumA = Object.values(a[1]).reduce((ss, inv) => ss + Object.values(inv.lots).reduce((sss, v) => sss + v.count, 0), 0);
      const sumB = Object.values(b[1]).reduce((ss, inv) => ss + Object.values(inv.lots).reduce((sss, v) => sss + v.count, 0), 0);
      return sumB - sumA;
    });

    sortedTypes.forEach(([type, invoices]) => {
      const typeTotal = Object.values(invoices).reduce((s, inv) => s + Object.values(inv.lots).reduce((ss, v) => ss + v.count, 0), 0);
      const numInvoices = Object.keys(invoices).length;
      const numLots = Object.values(invoices).reduce((s, inv) => s + Object.keys(inv.lots).length, 0);

      html += `<div class="paper-subgroup">
        <div class="paper-header">
          <span class="paper-name">${escapeHtml(type)}</span>
          <span class="paper-count">${numInvoices} invoices · ${numLots} lots · ${typeTotal} ม้วน</span>
        </div>`;
      
      // Sort invoices: __NO_INVOICE__ last, then by receive_date desc
      const sortedInvoices = Object.entries(invoices).sort((a, b) => {
        if (a[0] === '__NO_INVOICE__') return 1;
        if (b[0] === '__NO_INVOICE__') return -1;
        return (b[1].receive_date || '').localeCompare(a[1].receive_date || '');
      });

      sortedInvoices.forEach(([invKey, invData]) => {
        const invTotal = Object.values(invData.lots).reduce((s, v) => s + v.count, 0);
        const numLotsInInv = Object.keys(invData.lots).length;
        
        // Invoice sub-header
        if (invKey === '__NO_INVOICE__') {
          html += `<div class="invoice-sub-header" style="background:#fef3c7;border-left:3px solid #d97706;">
            <span style="color:#78350f;font-weight:700;">❓ ไม่มีข้อมูล Invoice</span>
            <span style="color:#92400e;font-size:11px;margin-left:6px;">(${numLotsInInv} lots · ${invTotal} ม้วน)</span>
          </div>`;
        } else {
          html += `<div class="invoice-sub-header">
            <span class="invoice-label">📄 ${escapeHtml(invData.invoice_no)}</span>
            <span class="invoice-supplier">${escapeHtml(invData.supplier || '-')}</span>
            ${invData.receive_date ? `<span class="invoice-date">รับเข้า ${invData.receive_date}</span>` : ''}
            <span class="invoice-lots-count">${numLotsInInv} lots · ${invTotal} ม้วน</span>
          </div>`;
        }
        
        // Lots under this invoice
        const sortedLots = Object.entries(invData.lots).sort((a, b) => b[1].count - a[1].count);
        sortedLots.forEach(([lot, info]) => {
          html += `<div class="lot-row">
            <div>
              <div class="lot-name">${escapeHtml(lot)}</div>
              <div class="lot-meta">ตัด ${escapeHtml(info.cut_date)} · Slitter ${escapeHtml(info.slitter)}${!params.machineId ? ' · ' + escapeHtml(info.machine_name) : ''}</div>
            </div>
            <div class="lot-count">${info.count}×</div>
          </div>`;
        });
      });
      
      html += `</div>`;
    });

    html += `</div></div>`;  // close trace-group-details, trace-group
  });

  // ==================== Supplier Report (text) ====================
  let report = `รายงานสอบกลับวัตถุดิบกระดาษ\n`;
  report += `════════════════════════════════════════\n`;
  report += `วันที่ผลิต : ${params.date}\n`;
  const machineName = params.machineId ? (document.getElementById('t-machine').options[document.getElementById('t-machine').selectedIndex].text) : '(ทุกเครื่อง)';
  report += `เครื่อง    : ${machineName}\n`;
  report += `สินค้า     : ${params.product || '(ทุกสินค้า)'}\n`;
  report += `════════════════════════════════════════\n\n`;

  sortedProducts.forEach(prod => {
    const productTotal = Object.values(prod.types).reduce((s, t) => 
      s + Object.values(t).reduce((ss, inv) => 
        ss + Object.values(inv.lots).reduce((sss, v) => sss + v.count, 0), 0), 0);
    report += `📦 ${prod.name}${prod.isNew ? ' (สินค้าใหม่)' : ''} — ${productTotal} ม้วน\n`;
    
    Object.entries(prod.types).forEach(([type, invoices]) => {
      const typeTotal = Object.values(invoices).reduce((s, inv) => s + Object.values(inv.lots).reduce((ss, v) => ss + v.count, 0), 0);
      const numInvoices = Object.keys(invoices).length;
      const numLots = Object.values(invoices).reduce((s, inv) => s + Object.keys(inv.lots).length, 0);
      report += `  ● ${type} (${numInvoices} invoices, ${numLots} lots, ${typeTotal} ม้วน)\n`;
      
      // Sort invoices
      const sortedInvs = Object.entries(invoices).sort((a, b) => {
        if (a[0] === '__NO_INVOICE__') return 1;
        if (b[0] === '__NO_INVOICE__') return -1;
        return (b[1].receive_date || '').localeCompare(a[1].receive_date || '');
      });
      
      sortedInvs.forEach(([invKey, invData]) => {
        if (invKey === '__NO_INVOICE__') {
          report += `     📄 (ไม่มีข้อมูล Invoice)\n`;
        } else {
          const supInfo = invData.supplier ? `${invData.supplier}` : '';
          const dateInfo = invData.receive_date ? `, รับเข้า ${invData.receive_date}` : '';
          report += `     📄 Invoice: ${invData.invoice_no} (${supInfo}${dateInfo})\n`;
        }
        
        Object.entries(invData.lots).sort((a, b) => b[1].count - a[1].count).forEach(([lot, info]) => {
          report += `        - ${lot}  (ตัด ${info.cut_date}) × ${info.count}\n`;
        });
      });
    });
    report += '\n';
  });
  report += `════════════════════════════════════════\n`;
  report += `รวม: ${totalProducts} สินค้า, ${totalTypes} ประเภทกระดาษ, ${totalInvoices} Invoices, ${totalLots} Jumbo Lots, ${totalRolls} ม้วน\n`;

  // Inject report ขึ้นไปบนสุด (แทน placeholder)
  const reportHtml = `<div class="report-box report-box-top">
    <div class="report-header">
      <div class="report-title">📄 รายงานพร้อมส่ง Supplier (พร้อม copy)</div>
      <button class="copy-btn" id="btn-copy-report-top">📋 Copy</button>
    </div>
    <div class="report-content">${escapeHtml(report)}</div>
  </div>`;
  html = html.replace('<div id="trace-report-placeholder"></div>', reportHtml);

  container.innerHTML = html;
  window._reportText = report;

  // Copy button
  const btnCopy = document.getElementById('btn-copy-report-top');
  if (btnCopy) {
    btnCopy.addEventListener('click', () => {
      navigator.clipboard.writeText(window._reportText).then(() => {
        const orig = btnCopy.textContent;
        btnCopy.textContent = '✓ คัดลอกแล้ว';
        setTimeout(() => btnCopy.textContent = orig, 2000);
      });
    });
  }

  // Export CSV button
  document.getElementById('btn-export-trace').addEventListener('click', () => {
    const rows = window._traceData
      .sort((a, b) => (a.product_name || '').localeCompare(b.product_name || '') ||
                      (a.paper_type || '').localeCompare(b.paper_type || '') ||
                      (a.jumbo_lot || '').localeCompare(b.jumbo_lot || ''))
      .map(scanToRow);
    const csv = rowsToCSV(SCAN_CSV_HEADERS, rows);
    const p = window._traceParams;
    const machineName = p.machineId
      ? document.getElementById('t-machine').options[document.getElementById('t-machine').selectedIndex].text.replace(/\s.*$/, '')
      : 'all';
    const fname = `trace_${p.date}_${machineName}${p.product ? '_' + p.product : ''}_${timestamp()}.csv`;
    downloadCSV(csv, fname);
  });
}

document.getElementById('btn-trace').addEventListener('click', runTrace);

// Toggle product group expand/collapse
window.toggleProdGroup = function(prodId) {
  const el = document.getElementById(prodId);
  const arrow = document.getElementById('arrow-' + prodId);
  if (!el) return;
  if (el.style.display === 'none') {
    el.style.display = 'block';
    if (arrow) arrow.textContent = '▼';
  } else {
    el.style.display = 'none';
    if (arrow) arrow.textContent = '▶';
  }
};

// ==================== VIEW 2: LOT LOOKUP ====================
async function runLotLookup() {
  const q = document.getElementById('l-input').value.trim();
  const container = document.getElementById('l-result');

  if (!q) {
    container.innerHTML = '<div class="empty"><span class="emoji">📦</span><div class="empty-title">พิมพ์เลขล็อตเพื่อเริ่มค้นหา</div></div>';
    return;
  }

  container.innerHTML = '<div class="loading"><div class="spinner-small"></div><div style="margin-top:10px;">กำลังค้นหา...</div></div>';

  try {
    const { data, error } = await supabase
      .from('v_scan_details')
      .select('*')
      .ilike('jumbo_lot', `%${q}%`)
      .order('production_date', { ascending: false })
      .limit(500);

    if (error) throw error;

    if (!data || data.length === 0) {
      container.innerHTML = `<div class="empty"><span class="emoji">📭</span><div class="empty-title">ไม่พบ Jumbo Lot "${escapeHtml(q)}"</div></div>`;
      return;
    }

    // ดึง invoice info สำหรับ lots ที่เจอ
    const lotsForInvQuery = [...new Set(data.map(s => (s.jumbo_lot || '').replace(/-/g, '').toUpperCase()))];
    let invoiceMap = {};
    if (lotsForInvQuery.length > 0) {
      const { data: invData } = await supabase
        .from('paper_invoices')
        .select('paper_lot, paper_lot_normalized, invoice_no, supplier, receive_date, weight_kg')
        .in('paper_lot_normalized', lotsForInvQuery);
      (invData || []).forEach(inv => {
        invoiceMap[inv.paper_lot_normalized] = inv;
      });
    }

    window._lotData = data;
    window._lotQuery = q;

    // Group by lot (top level) → ภายในแต่ละ lot group ต่อโดย date+machine+product
    const byLot = {};
    data.forEach(s => {
      const lotKey = s.jumbo_lot;
      if (!byLot[lotKey]) {
        byLot[lotKey] = {
          lot: s.jumbo_lot,
          paper_type: s.paper_type,
          cut_date: s.cut_date,
          slitters: new Set(),
          totalCount: 0,
          usages: {}  // key: date|machine|product
        };
      }
      if (s.slitter) byLot[lotKey].slitters.add(String(s.slitter));
      const useKey = `${s.production_date}|${s.machine_id}|${s.product_name}`;
      if (!byLot[lotKey].usages[useKey]) {
        byLot[lotKey].usages[useKey] = {
          date: s.production_date,
          machine: s.machine_name,
          product: s.product_name,
          isNew: s.is_new_product,
          count: 0
        };
      }
      byLot[lotKey].usages[useKey].count++;
      byLot[lotKey].totalCount++;
    });

    // เรียง lot ตาม alphabet
    const lotGroups = Object.values(byLot).sort((a, b) => a.lot.localeCompare(b.lot));
    const totalScans = data.length;
    const uniqueLots = Object.keys(byLot).length;
    const uniqueDays = new Set(data.map(d => d.production_date)).size;
    const uniqueProducts = new Set(data.map(d => d.product_name)).size;

    let html = `<div class="panel-actions">
      <button class="export-btn" id="btn-export-lot">📥 Export CSV (${totalScans} rows)</button>
    </div>
    <div class="lot-summary">
      <div class="lot-summary-card"><div class="lot-summary-label">Lots ที่ match</div><div class="lot-summary-value">${uniqueLots}</div></div>
      <div class="lot-summary-card"><div class="lot-summary-label">วันที่ใช้</div><div class="lot-summary-value">${uniqueDays}</div></div>
      <div class="lot-summary-card"><div class="lot-summary-label">สินค้าที่ผลิต</div><div class="lot-summary-value">${uniqueProducts}</div></div>
      <div class="lot-summary-card"><div class="lot-summary-label">ม้วนทั้งหมด</div><div class="lot-summary-value">${totalScans}</div></div>
    </div>`;

    lotGroups.forEach(lg => {
      const usageList = Object.values(lg.usages).sort((a, b) => {
        if (a.date !== b.date) return b.date.localeCompare(a.date);
        return a.product.localeCompare(b.product);
      });
      
      // ค้นหา invoice info
      const lotNorm = (lg.lot || '').replace(/-/g, '').toUpperCase();
      const inv = invoiceMap[lotNorm];
      const invBadge = inv 
        ? `<div class="lot-invoice-cards">
             <div class="lot-invoice-card">
               <div class="lot-invoice-label">📄 Invoice</div>
               <div class="lot-invoice-value">${escapeHtml(inv.invoice_no || '-')}</div>
             </div>
             <div class="lot-invoice-card">
               <div class="lot-invoice-label">🏭 Supplier</div>
               <div class="lot-invoice-value">${escapeHtml(inv.supplier || '-')}</div>
             </div>
             <div class="lot-invoice-card">
               <div class="lot-invoice-label">📅 รับเข้า</div>
               <div class="lot-invoice-value">${inv.receive_date || '-'}</div>
               ${inv.weight_kg ? `<div class="lot-invoice-sub">${Math.round(Number(inv.weight_kg)).toLocaleString()} kg</div>` : ''}
             </div>
           </div>`
        : `<div class="lot-invoice-empty">⚠️ ไม่พบข้อมูล Invoice สำหรับ lot นี้</div>`;
      
      html += `<div class="lot-group">
        <div class="lot-group-header">
          <div class="lot-group-title">
            📦 <strong class="lot-no">${highlightMatch(lg.lot, q, 'lot-hl')}</strong>
            <span class="lot-group-meta">${escapeHtml(lg.paper_type)} · ตัด ${escapeHtml(lg.cut_date)}${lg.slitters && lg.slitters.size > 0 ? ` · ✂️ Slitter ${[...lg.slitters].sort().join(',')}` : ''}</span>
          </div>
          <div class="lot-group-total">${lg.totalCount} ม้วน</div>
        </div>
        ${invBadge}
        <div class="lot-group-body">`;
      usageList.forEach((u, i) => {
        html += `<div class="lot-usage-row">
          <div class="lot-usage-info">
            <span class="lot-usage-date">${u.date}</span>
            <span class="lot-usage-sep">·</span>
            <span class="lot-usage-machine">${escapeHtml(u.machine)}</span>
            <span class="lot-usage-sep">·</span>
            <strong class="lot-usage-product">${escapeHtml(u.product)}</strong>
            ${u.isNew ? '<span class="new-badge-sm">ใหม่</span>' : ''}
          </div>
          <div class="lot-usage-count">${u.count} ม้วน</div>
        </div>`;
      });
      html += `</div></div>`;
    });

    container.innerHTML = html;

    // Export handler
    document.getElementById('btn-export-lot').addEventListener('click', () => {
      const rows = window._lotData
        .sort((a, b) => (b.production_date || '').localeCompare(a.production_date || '') ||
                        (a.jumbo_lot || '').localeCompare(b.jumbo_lot || ''))
        .map(scanToRow);
      const csv = rowsToCSV(SCAN_CSV_HEADERS, rows);
      const safeQ = window._lotQuery.replace(/[^a-zA-Z0-9\-_]/g, '_');
      downloadCSV(csv, `lot_search_${safeQ}_${timestamp()}.csv`);
    });
  } catch (err) {
    console.error(err);
    container.innerHTML = `<div class="empty"><span class="emoji">⚠️</span><div class="empty-title">ค้นหาไม่สำเร็จ</div><div>${escapeHtml(err.message)}</div></div>`;
  }
}

document.getElementById('btn-lot').addEventListener('click', runLotLookup);
document.getElementById('l-input').addEventListener('keydown', e => {
  if (e.key === 'Enter') runLotLookup();
});

// ==================== VIEW: INVOICE TRACKER ====================
async function runInvoiceSearch() {
  const invNo = document.getElementById('inv-no').value.trim();
  const supplier = document.getElementById('inv-supplier').value;
  const fromDate = document.getElementById('inv-from').value;
  const toDate = document.getElementById('inv-to').value;

  if (!invNo && !supplier && !fromDate && !toDate) {
    alert('กรุณากรอกเงื่อนไขค้นหาอย่างน้อย 1 ตัว');
    return;
  }

  const container = document.getElementById('inv-result');
  container.innerHTML = '<div class="loading"><div class="spinner-small"></div><div style="margin-top:10px;">กำลังค้นหา...</div></div>';

  try {
    let query = supabase
      .from('paper_invoices')
      .select('*')
      .order('receive_date', { ascending: false })
      .limit(1000);

    if (invNo) query = query.ilike('invoice_no', `%${invNo}%`);
    if (supplier) query = query.eq('supplier', supplier);
    if (fromDate) query = query.gte('receive_date', fromDate);
    if (toDate) query = query.lte('receive_date', toDate);

    const { data: invoices, error } = await query;
    if (error) throw error;

    if (!invoices || invoices.length === 0) {
      container.innerHTML = `<div class="empty"><span class="emoji">📭</span><div class="empty-title">ไม่พบ Invoice ที่ตรงกับเงื่อนไข</div></div>`;
      return;
    }

    // ดึง scan data ที่ใช้ lots เหล่านี้
    const lotNormalized = invoices.map(i => i.paper_lot_normalized);
    const { data: scans } = await supabase
      .from('v_scan_details')
      .select('jumbo_lot, production_date, machine_name, product_name')
      .limit(5000);

    // Normalize scan lots
    const scanByLot = {};
    (scans || []).forEach(s => {
      const norm = (s.jumbo_lot || '').replace(/-/g, '').toUpperCase();
      if (!scanByLot[norm]) scanByLot[norm] = [];
      scanByLot[norm].push(s);
    });

    // Group invoices by invoice_no
    const byInvoice = {};
    invoices.forEach(inv => {
      const key = inv.invoice_no || '(ไม่ระบุ)';
      if (!byInvoice[key]) {
        byInvoice[key] = {
          invoice_no: key,
          supplier: inv.supplier,
          receive_date: inv.receive_date,
          invoice_date: inv.invoice_date,
          lots: [],
          total_weight: 0,
          total_rolls: 0,
          paper_types: new Set()
        };
      }
      byInvoice[key].lots.push(inv);
      byInvoice[key].total_weight += Number(inv.weight_kg) || 0;
      byInvoice[key].total_rolls++;
      if (inv.paper_type) byInvoice[key].paper_types.add(inv.paper_type);
    });

    const invList = Object.values(byInvoice).sort((a, b) =>
      (b.receive_date || '').localeCompare(a.receive_date || '')
    );

    // Stats
    const totalInvs = invList.length;
    const totalLots = invoices.length;
    const usedLots = invoices.filter(i => scanByLot[i.paper_lot_normalized]).length;
    const usageRate = totalLots > 0 ? (usedLots / totalLots * 100).toFixed(1) : 0;

    let html = `<div class="lot-summary">
      <div class="lot-summary-card"><div class="lot-summary-label">Invoices</div><div class="lot-summary-value">${totalInvs}</div></div>
      <div class="lot-summary-card"><div class="lot-summary-label">ม้วนทั้งหมด</div><div class="lot-summary-value">${totalLots}</div></div>
      <div class="lot-summary-card"><div class="lot-summary-label">ใช้ไปแล้ว</div><div class="lot-summary-value" style="color:var(--accent);">${usedLots} <span style="font-size:12px;color:var(--text-dim);">(${usageRate}%)</span></div></div>
      <div class="lot-summary-card"><div class="lot-summary-label">รอใช้</div><div class="lot-summary-value" style="color:var(--accent-2);">${totalLots - usedLots}</div></div>
    </div>`;

    invList.forEach(inv => {
      const papers = Array.from(inv.paper_types).join(', ');
      const usedInInv = inv.lots.filter(l => scanByLot[l.paper_lot_normalized]).length;

      html += `<div class="lot-group">
        <div class="lot-group-header">
          <div class="lot-group-title">
            📄 <strong class="lot-no">${escapeHtml(inv.invoice_no)}</strong>
            <span class="lot-group-meta">${escapeHtml(inv.supplier || '-')} · รับเข้า ${inv.receive_date || '-'} · ${papers}</span>
          </div>
          <div class="lot-group-total">${inv.total_rolls} ม้วน · ${Math.round(inv.total_weight).toLocaleString()} kg · ใช้ ${usedInInv}/${inv.total_rolls}</div>
        </div>
        <div class="lot-group-body">`;

      inv.lots.slice(0, 50).forEach(l => {
        const uses = scanByLot[l.paper_lot_normalized] || [];
        const usageText = uses.length > 0
          ? uses.slice(0, 3).map(u => `${u.production_date}·${u.machine_name}·${u.product_name}`).join(' | ') +
            (uses.length > 3 ? ` +${uses.length - 3} อื่น` : '')
          : '<span style="color:var(--text-dim);">(ยังไม่ได้ใช้)</span>';

        html += `<div class="lot-usage-row">
          <div class="lot-usage-info" style="flex:2;">
            <strong>${escapeHtml(l.paper_lot)}</strong>
            <span class="lot-usage-sep">·</span>
            <span class="lot-usage-machine">${escapeHtml(l.paper_type || '-')}</span>
            <span class="lot-usage-sep">·</span>
            <span style="color:var(--text-dim);">${Math.round(Number(l.weight_kg) || 0)} kg</span>
          </div>
          <div style="font-size:11px;color:var(--text-dim);flex:3;text-align:right;">${usageText}</div>
        </div>`;
      });

      if (inv.lots.length > 50) {
        html += `<div style="padding:8px 14px;font-size:12px;color:var(--text-dim);">... และอีก ${inv.lots.length - 50} lots</div>`;
      }

      html += `</div></div>`;
    });

    container.innerHTML = html;
  } catch (err) {
    console.error(err);
    container.innerHTML = `<div class="empty"><span class="emoji">⚠️</span><div class="empty-title">ค้นหาไม่สำเร็จ</div><div>${escapeHtml(err.message)}</div></div>`;
  }
}

document.getElementById('btn-invoice').addEventListener('click', runInvoiceSearch);
document.getElementById('inv-no').addEventListener('keydown', e => {
  if (e.key === 'Enter') runInvoiceSearch();
});

// ==================== VIEW 3: HISTORY ====================
async function loadHistory() {
  const fromDate = document.getElementById('h-from').value;
  const toDate = document.getElementById('h-to').value;
  const machineId = document.getElementById('h-machine').value;

  if (!fromDate || !toDate) {
    alert('กรุณาเลือกช่วงวันที่');
    return;
  }
  if (fromDate > toDate) {
    alert('วันที่ "จาก" ต้องน้อยกว่าหรือเท่ากับ "ถึง"');
    return;
  }

  const container = document.getElementById('h-result');
  container.innerHTML = '<div class="loading"><div class="spinner-small"></div><div style="margin-top:10px;">กำลังค้นหา...</div></div>';
  document.getElementById('stats-box').style.display = 'none';

  try {
    const showVoided = document.getElementById('h-show-voided').checked;

    // Get batches with filter
    let batchQuery = supabase
      .from('production_batches')
      .select(`
        id,
        production_date,
        submitted_at,
        machine_id,
        voided,
        voided_reason,
        machines (name, dp),
        batch_products (product_name, is_new_product, sequence)
      `)
      .gte('production_date', fromDate)
      .lte('production_date', toDate)
      .order('production_date', { ascending: false })
      .order('submitted_at', { ascending: false });

    if (machineId) batchQuery = batchQuery.eq('machine_id', parseInt(machineId));
    if (!showVoided) batchQuery = batchQuery.eq('voided', false);

    const { data: batches, error: bErr } = await batchQuery;
    if (bErr) throw bErr;

    if (!batches || batches.length === 0) {
      container.innerHTML = '<div class="empty"><span class="emoji">📭</span><div class="empty-title">ไม่พบ batch ในช่วงเวลานี้</div><div>ลองขยายช่วงวันที่ หรือเปลี่ยนเครื่อง</div></div>';
      return;
    }

    // Get scan counts per batch
    const batchIds = batches.map(b => b.id);
    const { data: scans, error: sErr } = await supabase
      .from('paper_scans')
      .select('batch_id, jumbo_lot')
      .in('batch_id', batchIds);
    if (sErr) throw sErr;

    const countsByBatch = {};
    const lotsByBatch = {};
    scans.forEach(s => {
      countsByBatch[s.batch_id] = (countsByBatch[s.batch_id] || 0) + 1;
      if (!lotsByBatch[s.batch_id]) lotsByBatch[s.batch_id] = new Set();
      lotsByBatch[s.batch_id].add(s.jumbo_lot);
    });

    // Stats
    const totalScans = scans.length;
    const totalLots = new Set(scans.map(s => s.jumbo_lot)).size;
    const totalNew = batches.reduce((sum, b) =>
      sum + (b.batch_products || []).filter(p => p.is_new_product).length, 0);

    document.getElementById('st-batches').textContent = batches.length;
    document.getElementById('st-scans').textContent = totalScans;
    document.getElementById('st-lots').textContent = totalLots;
    document.getElementById('st-new').textContent = totalNew;
    document.getElementById('stats-box').style.display = 'grid';

    if (batches.length === 0) {
      container.innerHTML = '<div class="empty"><span class="emoji">📭</span><div class="empty-title">ยังไม่มีประวัติการบันทึก</div></div>';
      return;
    }

    // Store for export
    window._historyBatches = batches;
    window._historyScans = scans;

    // Build lookup maps for export
    const batchMap = {};
    batches.forEach(b => {
      batchMap[b.id] = {
        production_date: b.production_date,
        machine_name: b.machines ? b.machines.name : null,
        submitted_at: b.submitted_at,
        products: {}
      };
      (b.batch_products || []).forEach(bp => {
        // not directly usable since batch_products doesn't have id in this join
      });
    });

    let html = `<div class="panel-actions">
      <button class="export-btn" id="btn-export-history">📥 Export CSV (ทุกม้วนใน ${batches.length} batches)</button>
    </div>
    <div class="batch-list">`;
    batches.forEach(b => {
      const productNames = (b.batch_products || [])
        .sort((a, b) => a.sequence - b.sequence)
        .map(p => p.product_name + (p.is_new_product ? ' (ใหม่)' : ''))
        .join(', ');
      const machineName = b.machines ? b.machines.name : '-';
      const cnt = countsByBatch[b.id] || 0;
      const isVoided = b.voided;
      const voidedBadge = isVoided
        ? `<span style="display:inline-block;padding:2px 8px;background:var(--danger);color:white;border-radius:5px;font-size:10px;font-weight:800;margin-left:8px;">ยกเลิกแล้ว</span>`
        : '';
      html += `<div class="batch-item" data-batch-id="${b.id}" style="cursor:pointer; ${isVoided ? 'opacity:0.6; background:#fef2f2;' : ''}">
        <div>
          <div class="batch-date">${b.production_date}${voidedBadge}</div>
          <div style="font-size:11px;color:var(--text-dim);">${new Date(b.submitted_at).toLocaleString('th-TH')}${isVoided && b.voided_reason ? ' · ' + escapeHtml(b.voided_reason) : ''}</div>
        </div>
        <div class="batch-machine">${escapeHtml(machineName)}</div>
        <div class="batch-products" title="${escapeHtml(productNames)}">${escapeHtml(productNames.length > 50 ? productNames.substring(0, 47) + '...' : productNames)}</div>
        <div class="batch-count">${cnt} ม้วน</div>
        <div class="batch-arrow">›</div>
      </div>`;
    });
    html += '</div>';
    container.innerHTML = html;

    // Click to open detail modal
    container.querySelectorAll('.batch-item[data-batch-id]').forEach(item => {
      item.addEventListener('click', () => openBatchDetail(item.dataset.batchId));
    });

    // Export handler — need to fetch detailed scan info
    document.getElementById('btn-export-history').addEventListener('click', async () => {
      const btn = document.getElementById('btn-export-history');
      const orig = btn.innerHTML;
      btn.disabled = true;
      btn.innerHTML = '⏳ กำลังโหลด...';
      try {
        const batchIds = batches.map(b => b.id);
        const { data: details, error } = await supabase
          .from('v_scan_details')
          .select('*')
          .in('batch_id', batchIds)
          .order('production_date', { ascending: false })
          .order('scanned_at', { ascending: true });
        if (error) throw error;

        const rows = details.map(scanToRow);
        const csv = rowsToCSV(SCAN_CSV_HEADERS, rows);
        const machineLabel = machineId
          ? document.getElementById('h-machine').options[document.getElementById('h-machine').selectedIndex].text.replace(/\s.*$/, '')
          : 'all';
        downloadCSV(csv, `history_${fromDate}_to_${toDate}_${machineLabel}_${timestamp()}.csv`);
        btn.innerHTML = '✓ บันทึกแล้ว';
        setTimeout(() => {
          btn.innerHTML = orig;
          btn.disabled = false;
        }, 2000);
      } catch (err) {
        console.error(err);
        alert('Export ไม่สำเร็จ: ' + err.message);
        btn.innerHTML = orig;
        btn.disabled = false;
      }
    });
  } catch (err) {
    console.error(err);
    container.innerHTML = `<div class="empty"><span class="emoji">⚠️</span><div class="empty-title">โหลดไม่สำเร็จ</div><div>${escapeHtml(err.message)}</div></div>`;
  }
}

// ==================== Setup History Tab Handlers ====================
document.getElementById('btn-h-search').addEventListener('click', loadHistory);
document.getElementById('h-show-voided').addEventListener('change', loadHistory);
document.getElementById('btn-h-preset').addEventListener('click', () => {
  const today = new Date();
  const thirtyDaysAgo = new Date(today.getTime() - 30 * 24 * 60 * 60 * 1000);
  document.getElementById('h-from').valueAsDate = thirtyDaysAgo;
  document.getElementById('h-to').valueAsDate = today;
  document.getElementById('h-machine').value = '';
  loadHistory();
});

// ==================== VIEW 5: EDIT DATA ====================

// ---- State ----
let _currentEditor = null;  // { batch, products, scans, originalProducts, originalScans, changes }

// ---- Audit log helper ----
async function logEdit(action, tableName, recordId, fieldName, oldVal, newVal, batchId, note) {
  try {
    const ip = await getClientIP();
    await supabase.from('edit_audit_logs').insert({
      ip_address: ip,
      table_name: tableName,
      record_id: recordId,
      action,
      field_name: fieldName,
      old_value: oldVal == null ? null : String(oldVal),
      new_value: newVal == null ? null : String(newVal),
      batch_id: batchId,
      note
    });
  } catch (e) {
    console.warn('Audit log failed', e);
  }
}

// ---- Batch list ----
async function loadEditList() {
  const from = document.getElementById('e-from').value;
  const to = document.getElementById('e-to').value;
  const machineId = document.getElementById('e-machine').value;
  const showVoided = document.getElementById('e-show-voided').checked;

  if (!from || !to) {
    alert('กรุณาเลือกช่วงวันที่');
    return;
  }

  const container = document.getElementById('e-result');
  container.innerHTML = '<div class="loading"><div class="spinner-small"></div><div style="margin-top:10px;">กำลังค้นหา...</div></div>';

  try {
    let query = supabase
      .from('production_batches')
      .select(`
        id, production_date, submitted_at, voided, voided_at, voided_reason, machine_id,
        machines (name, dp),
        batch_products (id, product_name, is_new_product, sequence)
      `)
      .gte('production_date', from)
      .lte('production_date', to)
      .order('production_date', { ascending: false })
      .order('submitted_at', { ascending: false });

    if (machineId) query = query.eq('machine_id', parseInt(machineId));
    if (!showVoided) query = query.eq('voided', false);

    const { data: batches, error } = await query;
    if (error) throw error;

    if (!batches || batches.length === 0) {
      container.innerHTML = '<div class="empty"><span class="emoji">📭</span><div class="empty-title">ไม่พบ batch</div></div>';
      return;
    }

    // Get scan counts
    const batchIds = batches.map(b => b.id);
    const { data: scans } = await supabase
      .from('paper_scans')
      .select('batch_id')
      .in('batch_id', batchIds);
    const countsByBatch = {};
    (scans || []).forEach(s => { countsByBatch[s.batch_id] = (countsByBatch[s.batch_id] || 0) + 1; });

    let html = '<div class="edit-batch-list">';
    batches.forEach(b => {
      const products = (b.batch_products || [])
        .sort((a, b) => a.sequence - b.sequence)
        .map(p => p.product_name).join(', ');
      const machineName = b.machines ? b.machines.name : '-';
      const cnt = countsByBatch[b.id] || 0;
      const submittedTime = new Date(b.submitted_at).toLocaleString('th-TH');

      html += `<div class="edit-batch-card ${b.voided ? 'voided' : ''}">
        <div class="edit-batch-info">
          <div class="edit-batch-title">
            <span class="date">${b.production_date}</span>
            · <span class="machine">${escapeHtml(machineName)}</span>
            · ${cnt} ม้วน
            ${b.voided ? '<span class="voided-badge">ยกเลิกแล้ว</span>' : ''}
          </div>
          <div class="edit-batch-meta">
            📦 ${escapeHtml(products)}<br>
            <small>บันทึกเมื่อ ${escapeHtml(submittedTime)}${b.voided ? ' · ยกเลิก: ' + escapeHtml(b.voided_reason || '-') : ''}</small>
          </div>
        </div>
        <div class="edit-batch-actions">
          <button class="mini-btn edit" data-id="${b.id}">✏️ แก้ไข</button>
          ${b.voided
            ? `<button class="mini-btn restore" data-id="${b.id}">↻ กู้คืน</button>`
            : `<button class="mini-btn void" data-id="${b.id}">✕ ยกเลิก</button>`}
        </div>
      </div>`;
    });
    html += '</div>';
    container.innerHTML = html;

    // Attach handlers
    container.querySelectorAll('.mini-btn.edit').forEach(btn => {
      btn.addEventListener('click', () => openEditor(btn.dataset.id));
    });
    container.querySelectorAll('.mini-btn.void').forEach(btn => {
      btn.addEventListener('click', () => voidBatch(btn.dataset.id));
    });
    container.querySelectorAll('.mini-btn.restore').forEach(btn => {
      btn.addEventListener('click', () => restoreBatch(btn.dataset.id));
    });
  } catch (err) {
    console.error(err);
    container.innerHTML = `<div class="empty"><span class="emoji">⚠️</span><div class="empty-title">ค้นหาไม่สำเร็จ</div><div>${escapeHtml(err.message)}</div></div>`;
  }
}

// ---- Void / Restore ----
async function voidBatch(batchId) {
  const reason = prompt('กรุณาระบุเหตุผลในการยกเลิก batch นี้:');
  if (reason == null || !reason.trim()) return;

  try {
    const { error } = await supabase
      .from('production_batches')
      .update({
        voided: true,
        voided_at: new Date().toISOString(),
        voided_reason: reason.trim()
      })
      .eq('id', batchId);
    if (error) throw error;
    await logEdit('void', 'production_batches', batchId, null, null, reason.trim(), batchId, 'Voided batch');
    alert('✓ ยกเลิก batch เรียบร้อย');
    loadEditList();
  } catch (err) {
    console.error(err);
    alert('ยกเลิกไม่สำเร็จ: ' + err.message);
  }
}

async function restoreBatch(batchId) {
  if (!confirm('กู้คืน batch นี้ให้กลับมาใช้งาน?')) return;
  try {
    const { error } = await supabase
      .from('production_batches')
      .update({ voided: false, voided_at: null, voided_reason: null })
      .eq('id', batchId);
    if (error) throw error;
    await logEdit('restore', 'production_batches', batchId, null, null, null, batchId, 'Restored batch');
    alert('✓ กู้คืนเรียบร้อย');
    loadEditList();
  } catch (err) {
    console.error(err);
    alert('กู้คืนไม่สำเร็จ: ' + err.message);
  }
}

// ---- Editor ----
async function openEditor(batchId) {
  const listPanel = document.getElementById('edit-list-panel');
  const editorPanel = document.getElementById('edit-editor-panel');
  editorPanel.innerHTML = '<div class="loading"><div class="spinner-small"></div><div style="margin-top:10px;">กำลังโหลด batch...</div></div>';
  editorPanel.style.display = 'block';
  listPanel.style.display = 'none';

  try {
    // Load batch + products + scans
    const { data: batch, error: bErr } = await supabase
      .from('production_batches')
      .select(`
        id, production_date, machine_id, voided, voided_reason,
        machines (name, dp),
        batch_products (id, product_name, is_new_product, sequence)
      `)
      .eq('id', batchId)
      .single();
    if (bErr) throw bErr;

    const { data: scans, error: sErr } = await supabase
      .from('paper_scans')
      .select('*')
      .eq('batch_id', batchId)
      .order('scanned_at', { ascending: true });
    if (sErr) throw sErr;

    // Load audit log for this batch
    const { data: auditLog } = await supabase
      .from('edit_audit_logs')
      .select('*')
      .eq('batch_id', batchId)
      .order('edited_at', { ascending: false })
      .limit(20);

    _currentEditor = {
      batch: { ...batch },
      original: {
        production_date: batch.production_date,
        machine_id: batch.machine_id
      },
      products: batch.batch_products.sort((a, b) => a.sequence - b.sequence).map(p => ({ ...p, _original: { ...p } })),
      scans: scans.map(s => ({ ...s, _original: { ...s }, _deleted: false })),
      auditLog: auditLog || []
    };

    renderEditor();
  } catch (err) {
    console.error(err);
    editorPanel.innerHTML = `<div class="empty"><span class="emoji">⚠️</span><div class="empty-title">โหลดไม่สำเร็จ</div><div>${escapeHtml(err.message)}</div></div>`;
  }
}

function renderEditor() {
  const ed = _currentEditor;
  const panel = document.getElementById('edit-editor-panel');

  const machinesOpts = window._masterMachines.map(m =>
    `<option value="${m.id}" ${m.id === ed.batch.machine_id ? 'selected' : ''}>${escapeHtml(m.name)} (${escapeHtml(m.dp)})</option>`
  ).join('');

  const auditHtml = ed.auditLog.length === 0
    ? '<div style="color: var(--text-dim); font-size: 13px; padding: 8px;">ยังไม่มีประวัติการแก้ไข</div>'
    : ed.auditLog.map(a => {
        const t = new Date(a.edited_at).toLocaleString('th-TH');
        let diff = '';
        if (a.field_name) {
          diff = `<div class="audit-diff">
            ${a.field_name}:
            <span class="old">${escapeHtml(a.old_value || '(ว่าง)')}</span> →
            <span class="new">${escapeHtml(a.new_value || '(ว่าง)')}</span>
          </div>`;
        } else if (a.note) {
          diff = `<div class="audit-diff">${escapeHtml(a.note)}${a.new_value ? ': ' + escapeHtml(a.new_value) : ''}</div>`;
        }
        return `<div class="audit-entry">
          <span class="audit-action ${a.action}">${a.action.toUpperCase()}</span>
          <span class="audit-time">${t} · ${escapeHtml(a.ip_address || '-')}</span>
          <span style="margin-left: 4px; color: var(--text-dim); font-size: 11px;">${escapeHtml(a.table_name)}</span>
          ${diff}
        </div>`;
      }).join('');

  const productsHtml = ed.products.map((p, idx) => `
    <div class="edit-grid" style="margin-bottom: 8px; align-items: center; grid-template-columns: 32px 1fr 100px auto;">
      <div style="text-align:center; color: var(--text-dim); font-weight: 700;">${idx + 1}</div>
      <input type="text" class="p-edit-name" data-idx="${idx}" value="${escapeHtml(p.product_name)}" placeholder="ชื่อสินค้า">
      <label style="font-size:12px;display:flex;align-items:center;gap:6px;">
        <input type="checkbox" class="p-edit-new" data-idx="${idx}" ${p.is_new_product ? 'checked' : ''}>
        ใหม่
      </label>
      <button class="del-btn" data-idx="${idx}" title="ลบสินค้า (รวมม้วนทั้งหมดในสินค้านี้)" style="background:var(--danger-bg);color:var(--danger);border:1.5px solid var(--danger);border-radius:6px;padding:6px 12px;cursor:pointer;font-weight:700;">✕</button>
    </div>
  `).join('');

  // Group scans ที่ข้อมูลเหมือนกัน (paper_type + cut_date + slitter + jumbo_lot + batch_product_id)
  // เพื่อแก้ทีเดียวหลายม้วน
  // toggle: groupEditMode (default = true)
  if (typeof ed.groupEditMode === 'undefined') ed.groupEditMode = true;

  let scanRows;
  if (ed.groupEditMode) {
    // ---- Grouped Mode ----
    // Key = paper_type + cut_date + slitter + jumbo_lot (ไม่รวม batch_product_id)
    // ถ้าม้วนเดียวกันใช้กับหลายสินค้า → รวมเป็น 1 แถว, แสดงสินค้าทั้งหมดในช่อง multi-badges
    const groups = {};
    ed.scans.forEach((s, originalIdx) => {
      if (s._deleted) return;
      const key = [
        s.paper_type || '',
        s.cut_date || '',
        s.slitter || '',
        s.jumbo_lot || ''
      ].join('|');
      if (!groups[key]) {
        groups[key] = { ...s, _indices: [], _productIds: new Set(), _isGroup: true };
      }
      groups[key]._indices.push(originalIdx);
      if (s.batch_product_id) groups[key]._productIds.add(s.batch_product_id);
    });
    
    // Also add deleted scans as individual entries (ไม่ group)
    const deletedScans = ed.scans.map((s, idx) => ({ scan: s, idx })).filter(x => x.scan._deleted);
    
    let groupList = Object.values(groups);
    
    // Sort: paper_type → cut_date → slitter
    groupList.sort((a, b) => {
      const pt = (a.paper_type || '').localeCompare(b.paper_type || '');
      if (pt !== 0) return pt;
      const cd = (a.cut_date || '').localeCompare(b.cut_date || '');
      if (cd !== 0) return cd;
      // slitter เป็นตัวเลข — parse ก่อน compare
      const sA = parseInt(a.slitter) || 0;
      const sB = parseInt(b.slitter) || 0;
      if (sA !== sB) return sA - sB;
      return (a.jumbo_lot || '').localeCompare(b.jumbo_lot || '');
    });
    
    scanRows = groupList.map((g, gIdx) => {
      const isModified = g._indices.some(origIdx => {
        const s = ed.scans[origIdx];
        return JSON.stringify({a:s.barcode_raw,b:s.paper_type,c:s.cut_date,d:s.roll_no,e:s.slitter,f:s.jumbo_lot,g:s.batch_product_id}) !==
               JSON.stringify({a:s._original.barcode_raw,b:s._original.paper_type,c:s._original.cut_date,d:s._original.roll_no,e:s._original.slitter,f:s._original.jumbo_lot,g:s._original.batch_product_id});
      });
      const count = g._indices.length;
      const countBadge = count > 1 
        ? `<span class="group-count-badge" title="${count} ม้วนที่ข้อมูลเหมือนกัน">×${count}</span>`
        : `<span class="group-count-single">×1</span>`;
      
      // Product display: ถ้าใช้สินค้าเดียว → select แก้ได้, ถ้าหลายสินค้า → badges (read-only)
      const productIds = [...g._productIds];
      let productCell;
      if (productIds.length > 1) {
        // Multiple products → badges ไม่ให้แก้
        const productNames = productIds.map(pid => {
          const p = ed.products.find(pp => pp.id === pid);
          return p ? p.product_name : '?';
        });
        productCell = `<div class="product-badges" title="ม้วนเดียวใช้กับหลายสินค้า — ไม่สามารถเปลี่ยนสินค้าในโหมดรวมได้">
          ${productNames.map(n => `<span class="product-badge">${escapeHtml(n)}</span>`).join('')}
        </div>`;
      } else {
        const productOpts = ed.products.map(p =>
          `<option value="${p.id}" ${p.id === g.batch_product_id ? 'selected' : ''}>${escapeHtml(p.product_name)}</option>`
        ).join('');
        productCell = `<select class="s-edit-g" data-field="batch_product_id" data-gidx="${gIdx}" title="สินค้า">${productOpts}</select>`;
      }
      
      return `<div class="scan-edit-row ${isModified ? 'modified' : ''} ${count > 1 ? 'grouped' : ''}" data-gidx="${gIdx}">
        <div class="row-num">${countBadge}</div>
        ${productCell}
        <input type="text" class="s-edit-g" data-field="paper_type" data-gidx="${gIdx}" value="${escapeHtml(g.paper_type || '')}" placeholder="ประเภท">
        <input type="text" class="s-edit-g" data-field="cut_date" data-gidx="${gIdx}" value="${escapeHtml(g.cut_date || '')}" placeholder="ตัด">
        <input type="text" class="s-edit-g" data-field="slitter" data-gidx="${gIdx}" value="${escapeHtml(g.slitter || '')}" placeholder="slit">
        <input type="text" class="s-edit-g" data-field="jumbo_lot" data-gidx="${gIdx}" value="${escapeHtml(g.jumbo_lot || '')}" placeholder="ล็อต">
        <button class="del-btn scan-del-g" data-gidx="${gIdx}" title="ลบทั้งกลุ่ม (${count} ม้วน)">✕</button>
      </div>`;
    }).join('');
    
    // Add deleted scans ต่อท้าย (individual, ไม่ group)
    if (deletedScans.length > 0) {
      scanRows += `<div style="margin-top:10px;padding:8px;background:#fef3c7;border-radius:6px;font-size:12px;color:#78350f;font-weight:700;">🗑️ ม้วนที่จะถูกลบ (${deletedScans.length}):</div>`;
      deletedScans.forEach(({ scan: s, idx }) => {
        const productOpts = ed.products.map(p =>
          `<option value="${p.id}" ${p.id === s.batch_product_id ? 'selected' : ''}>${escapeHtml(p.product_name)}</option>`
        ).join('');
        scanRows += `<div class="scan-edit-row deleted" data-idx="${idx}">
          <div class="row-num">${idx + 1}</div>
          <select class="s-edit" data-field="batch_product_id" data-idx="${idx}" disabled>${productOpts}</select>
          <input type="text" class="s-edit" data-field="paper_type" data-idx="${idx}" value="${escapeHtml(s.paper_type || '')}" disabled>
          <input type="text" class="s-edit" data-field="cut_date" data-idx="${idx}" value="${escapeHtml(s.cut_date || '')}" disabled>
          <input type="text" class="s-edit" data-field="slitter" data-idx="${idx}" value="${escapeHtml(s.slitter || '')}" disabled>
          <input type="text" class="s-edit" data-field="jumbo_lot" data-idx="${idx}" value="${escapeHtml(s.jumbo_lot || '')}" disabled>
          <button class="del-btn scan-del" data-idx="${idx}" title="ยกเลิกลบ">↺</button>
        </div>`;
      });
    }
    
    // เก็บ group map สำหรับใช้ใน event handlers
    ed._currentGroups = groupList;
  } else {
    // ---- Individual Mode (เดิม) ----
    scanRows = ed.scans.map((s, idx) => {
      const isModified = JSON.stringify({a:s.barcode_raw,b:s.paper_type,c:s.cut_date,d:s.roll_no,e:s.slitter,f:s.jumbo_lot,g:s.batch_product_id}) !==
                         JSON.stringify({a:s._original.barcode_raw,b:s._original.paper_type,c:s._original.cut_date,d:s._original.roll_no,e:s._original.slitter,f:s._original.jumbo_lot,g:s._original.batch_product_id});
      const productOpts = ed.products.map(p =>
        `<option value="${p.id}" ${p.id === s.batch_product_id ? 'selected' : ''}>${escapeHtml(p.product_name)}</option>`
      ).join('');
      return `<div class="scan-edit-row ${isModified ? 'modified' : ''} ${s._deleted ? 'deleted' : ''}" data-idx="${idx}">
        <div class="row-num">${idx + 1}</div>
        <select class="s-edit" data-field="batch_product_id" data-idx="${idx}" title="สินค้า">${productOpts}</select>
        <input type="text" class="s-edit" data-field="paper_type" data-idx="${idx}" value="${escapeHtml(s.paper_type || '')}" placeholder="ประเภท">
        <input type="text" class="s-edit" data-field="cut_date" data-idx="${idx}" value="${escapeHtml(s.cut_date || '')}" placeholder="ตัด">
        <input type="text" class="s-edit" data-field="slitter" data-idx="${idx}" value="${escapeHtml(s.slitter || '')}" placeholder="slit">
        <input type="text" class="s-edit" data-field="jumbo_lot" data-idx="${idx}" value="${escapeHtml(s.jumbo_lot || '')}" placeholder="ล็อต">
        <button class="del-btn scan-del" data-idx="${idx}" title="${s._deleted ? 'ยกเลิกลบ' : 'ลบม้วนนี้'}">${s._deleted ? '↺' : '✕'}</button>
      </div>`;
    }).join('');
  }

  panel.innerHTML = `
    <div class="editor-header">
      <div class="editor-title">✏️ แก้ไข Batch
        ${ed.batch.voided ? '<span class="voided-badge" style="margin-left:8px;">ยกเลิกแล้ว</span>' : ''}
      </div>
      <button class="editor-back" id="btn-editor-back">← กลับไป list</button>
    </div>

    <div class="editor-section">
      <div class="editor-section-title">📋 ข้อมูลหัว Batch</div>
      <div class="edit-grid">
        <div>
          <label class="field-label">วันที่ผลิต</label>
          <input type="date" id="ed-date" value="${ed.batch.production_date}">
        </div>
        <div>
          <label class="field-label">เครื่องจักร</label>
          <select id="ed-machine">${machinesOpts}</select>
        </div>
      </div>
    </div>

    <div class="editor-section">
      <div class="editor-section-title">📦 สินค้าใน Batch (${ed.products.length})</div>
      ${productsHtml}
      <button class="mini-btn edit" id="btn-add-product" style="margin-top:8px;">+ เพิ่มสินค้า</button>
    </div>

    <div class="editor-section">
      <div class="editor-section-title" style="display:flex;justify-content:space-between;align-items:center;">
        <span>🧾 ม้วนที่สแกน (${ed.scans.filter(s => !s._deleted).length} / ${ed.scans.length})${ed.groupEditMode ? ` · <span style="color:var(--accent);">${ed._currentGroups ? ed._currentGroups.length : 0} กลุ่ม</span>` : ''}</span>
        <label style="font-size:12px;font-weight:600;display:flex;align-items:center;gap:6px;cursor:pointer;">
          <input type="checkbox" id="toggle-group-mode" ${ed.groupEditMode ? 'checked' : ''}>
          🔗 รวมข้อมูลเหมือนกัน
        </label>
      </div>
      <div style="font-size: 11px; color: var(--text-dim); margin-bottom: 8px;">
        ${ed.groupEditMode 
          ? '💡 <strong>Group Mode:</strong> ม้วนที่ข้อมูลเหมือนกันทุกช่อง = รวมเป็น 1 แถว (×จำนวน) · แก้ที่เดียว = อัพเดตทุกม้วน · ลบ = ลบทั้งกลุ่ม'
          : '💡 Tip: คลิกช่องเพื่อแก้ค่า · ปุ่ม ✕ = ลบม้วน (กลับได้ก่อน save)'
        }
      </div>
      ${scanRows}
    </div>

    <div class="editor-section">
      <div class="editor-section-title">📜 ประวัติการแก้ไข (20 ครั้งล่าสุด)</div>
      ${auditHtml}
    </div>

    <div class="editor-footer">
      <button class="btn btn-ghost" id="btn-editor-cancel">ยกเลิก (ไม่บันทึก)</button>
      <button class="btn" id="btn-editor-save">💾 บันทึกการแก้ไข</button>
    </div>
  `;

  // Attach handlers
  document.getElementById('btn-editor-back').addEventListener('click', closeEditor);
  document.getElementById('btn-editor-cancel').addEventListener('click', closeEditor);
  document.getElementById('btn-editor-save').addEventListener('click', saveEditor);
  document.getElementById('ed-date').addEventListener('change', e => ed.batch.production_date = e.target.value);
  document.getElementById('ed-machine').addEventListener('change', e => ed.batch.machine_id = parseInt(e.target.value));

  // Product edit
  panel.querySelectorAll('.p-edit-name').forEach(inp => {
    inp.addEventListener('input', e => {
      const idx = parseInt(e.target.dataset.idx);
      ed.products[idx].product_name = e.target.value;
    });
  });
  panel.querySelectorAll('.p-edit-new').forEach(inp => {
    inp.addEventListener('change', e => {
      const idx = parseInt(e.target.dataset.idx);
      ed.products[idx].is_new_product = e.target.checked;
    });
  });
  panel.querySelectorAll('.edit-grid .del-btn').forEach(btn => {
    btn.addEventListener('click', e => {
      const idx = parseInt(btn.dataset.idx);
      const prod = ed.products[idx];
      const scanCount = ed.scans.filter(s => s.batch_product_id === prod.id && !s._deleted).length;
      if (scanCount > 0) {
        if (!confirm(`สินค้า "${prod.product_name}" มี ${scanCount} ม้วน ถ้าลบ ม้วนทั้งหมดจะถูกลบด้วย ดำเนินการ?`)) return;
        ed.scans.forEach(s => { if (s.batch_product_id === prod.id) s._deleted = true; });
      }
      prod._deleted = true;
      ed.products.splice(idx, 1);
      renderEditor();
    });
  });
  document.getElementById('btn-add-product').addEventListener('click', () => {
    const name = prompt('ชื่อสินค้าใหม่:');
    if (!name || !name.trim()) return;
    const newProd = {
      id: 'new_' + Date.now(),  // marker ว่าเป็น new
      product_name: name.trim(),
      is_new_product: !window._masterProducts.includes(name.trim()),
      sequence: ed.products.length + 1,
      _isNew: true
    };
    ed.products.push(newProd);
    renderEditor();
  });

  // Scan edit (individual mode)
  panel.querySelectorAll('.s-edit').forEach(inp => {
    inp.addEventListener('input', e => {
      const idx = parseInt(e.target.dataset.idx);
      const field = e.target.dataset.field;
      const val = e.target.value;
      ed.scans[idx][field] = field === 'batch_product_id' ? val : val;
      const s = ed.scans[idx];
      s.barcode_raw = `${s.paper_type}_${s.cut_date}_${s.roll_no}_${s.slitter}_${s.jumbo_lot}`;
    });
    inp.addEventListener('blur', renderEditor);
  });
  panel.querySelectorAll('.scan-del').forEach(btn => {
    btn.addEventListener('click', () => {
      const idx = parseInt(btn.dataset.idx);
      ed.scans[idx]._deleted = !ed.scans[idx]._deleted;
      renderEditor();
    });
  });
  
  // Scan edit (group mode) — แก้ทีเดียว อัพเดตทุกม้วนในกลุ่ม
  // เพิ่ม confirmation เมื่อจะแก้ครั้งแรกในแต่ละ input ที่เป็นกลุ่ม >1 ม้วน
  panel.querySelectorAll('.s-edit-g').forEach(inp => {
    const gidx = parseInt(inp.dataset.gidx);
    const group = ed._currentGroups[gidx];
    const count = group ? group._indices.length : 1;
    const field = inp.dataset.field;
    
    // เก็บค่าเดิมไว้ตอนโฟกัส (กรณี user ยกเลิก)
    let originalVal = inp.value;
    let confirmed = false;
    
    inp.addEventListener('focus', e => {
      originalVal = e.target.value;
      confirmed = false;
    });
    
    inp.addEventListener('input', e => {
      // ถ้ายังไม่ confirmed และเป็นกลุ่มที่มี >1 ม้วน → เตือน
      if (count > 1 && !confirmed) {
        const fieldLabel = {
          'batch_product_id': 'สินค้า',
          'paper_type': 'ประเภทกระดาษ',
          'cut_date': 'วันที่ตัด',
          'slitter': 'Slitter',
          'jumbo_lot': 'Jumbo Lot'
        }[field] || field;
        
        const ok = confirm(
          `⚠️ ยืนยันการแก้ไข\n\n` +
          `คุณกำลังแก้ "${fieldLabel}" ของกลุ่มที่มี ${count} ม้วน\n` +
          `การแก้ไขนี้จะส่งผลกับทั้ง ${count} ม้วนพร้อมกัน\n\n` +
          `ต้องการดำเนินการต่อหรือไม่?`
        );
        
        if (!ok) {
          // ยกเลิก → คืนค่าเดิม
          e.target.value = originalVal;
          e.target.blur();
          return;
        }
        confirmed = true;  // ถือว่ายืนยันแล้ว = ไม่เตือนอีกใน focus นี้
      }
      
      const val = e.target.value;
      // Apply to all scans in group
      group._indices.forEach(origIdx => {
        const s = ed.scans[origIdx];
        s[field] = val;
        s.barcode_raw = `${s.paper_type}_${s.cut_date}_${s.roll_no}_${s.slitter}_${s.jumbo_lot}`;
      });
      // Also update the group object for re-render
      group[field] = val;
    });
    inp.addEventListener('blur', renderEditor);
  });
  panel.querySelectorAll('.scan-del-g').forEach(btn => {
    btn.addEventListener('click', () => {
      const gidx = parseInt(btn.dataset.gidx);
      const group = ed._currentGroups[gidx];
      if (!group) return;
      const count = group._indices.length;
      const groupInfo = `${group.paper_type || '-'} · ตัด ${group.cut_date || '-'} · Slitter ${group.slitter || '-'} · Lot ${group.jumbo_lot || '-'}`;
      if (count > 1) {
        if (!confirm(`⚠️ ยืนยันการลบ\n\nลบ ${count} ม้วนที่มีข้อมูลเหมือนกันนี้?\n\n${groupInfo}\n\n(กลับได้ก่อน save)`)) return;
      } else {
        if (!confirm(`ลบม้วนนี้?\n\n${groupInfo}\n\n(กลับได้ก่อน save)`)) return;
      }
      group._indices.forEach(origIdx => {
        ed.scans[origIdx]._deleted = true;
      });
      renderEditor();
    });
  });
  
  // Toggle group mode
  const toggleGroupBtn = document.getElementById('toggle-group-mode');
  if (toggleGroupBtn) {
    toggleGroupBtn.addEventListener('change', e => {
      ed.groupEditMode = e.target.checked;
      renderEditor();
    });
  }
}

function closeEditor() {
  if (_currentEditor && hasChanges()) {
    if (!confirm('มีการแก้ไขที่ยังไม่ได้บันทึก ต้องการออกโดยไม่บันทึก?')) return;
  }
  _currentEditor = null;
  document.getElementById('edit-editor-panel').style.display = 'none';
  document.getElementById('edit-list-panel').style.display = 'block';
  loadEditList();  // refresh
}

function hasChanges() {
  const ed = _currentEditor;
  if (!ed) return false;
  if (ed.batch.production_date !== ed.original.production_date) return true;
  if (ed.batch.machine_id !== ed.original.machine_id) return true;
  if (ed.products.some(p => p._isNew || p._deleted ||
      p.product_name !== p._original?.product_name ||
      p.is_new_product !== p._original?.is_new_product)) return true;
  if (ed.scans.some(s => s._deleted ||
      s.batch_product_id !== s._original.batch_product_id ||
      s.paper_type !== s._original.paper_type ||
      s.cut_date !== s._original.cut_date ||
      s.slitter !== s._original.slitter ||
      s.jumbo_lot !== s._original.jumbo_lot)) return true;
  return false;
}

async function saveEditor() {
  const ed = _currentEditor;
  if (!ed) return;
  if (!hasChanges()) {
    alert('ไม่มีการเปลี่ยนแปลง');
    return;
  }

  const saveBtn = document.getElementById('btn-editor-save');
  saveBtn.disabled = true;
  saveBtn.textContent = '⏳ กำลังบันทึก...';

  try {
    const batchId = ed.batch.id;
    const changes = [];  // { action, table, id, field, old, new }

    // 1. Batch header changes
    if (ed.batch.production_date !== ed.original.production_date) {
      await supabase.from('production_batches')
        .update({ production_date: ed.batch.production_date })
        .eq('id', batchId);
      changes.push({ action: 'update', table: 'production_batches', id: batchId,
                     field: 'production_date', old: ed.original.production_date, new: ed.batch.production_date });
    }
    if (ed.batch.machine_id !== ed.original.machine_id) {
      await supabase.from('production_batches')
        .update({ machine_id: ed.batch.machine_id })
        .eq('id', batchId);
      changes.push({ action: 'update', table: 'production_batches', id: batchId,
                     field: 'machine_id', old: ed.original.machine_id, new: ed.batch.machine_id });
    }

    // 2. Product changes: insert new, update modified, delete removed
    for (const p of ed.products) {
      if (p._isNew) {
        const { data, error } = await supabase.from('batch_products').insert({
          batch_id: batchId,
          product_name: p.product_name,
          is_new_product: p.is_new_product,
          sequence: p.sequence
        }).select().single();
        if (error) throw error;
        // Remap p.id so any scan pointing to this new product works
        const oldMarker = p.id;
        p.id = data.id;
        ed.scans.forEach(s => { if (s.batch_product_id === oldMarker) s.batch_product_id = data.id; });
        changes.push({ action: 'insert', table: 'batch_products', id: data.id, field: null,
                       old: null, new: p.product_name });
      } else if (p._original && (p.product_name !== p._original.product_name || p.is_new_product !== p._original.is_new_product)) {
        await supabase.from('batch_products').update({
          product_name: p.product_name,
          is_new_product: p.is_new_product
        }).eq('id', p.id);
        if (p.product_name !== p._original.product_name) {
          changes.push({ action: 'update', table: 'batch_products', id: p.id,
                         field: 'product_name', old: p._original.product_name, new: p.product_name });
        }
      }
    }

    // 3. Scan changes: update modified, delete marked
    for (const s of ed.scans) {
      if (s._deleted && !String(s.id).startsWith('new_')) {
        await supabase.from('paper_scans').delete().eq('id', s.id);
        changes.push({ action: 'delete', table: 'paper_scans', id: s.id, field: null,
                       old: s._original.barcode_raw, new: null });
        continue;
      }
      const modified =
        s.batch_product_id !== s._original.batch_product_id ||
        s.paper_type !== s._original.paper_type ||
        s.cut_date !== s._original.cut_date ||
        s.slitter !== s._original.slitter ||
        s.jumbo_lot !== s._original.jumbo_lot;
      if (modified && !s._deleted) {
        await supabase.from('paper_scans').update({
          batch_product_id: s.batch_product_id,
          paper_type: s.paper_type,
          cut_date: s.cut_date,
          slitter: s.slitter,
          jumbo_lot: s.jumbo_lot,
          barcode_raw: s.barcode_raw
        }).eq('id', s.id);
        // Log per-field changes
        ['batch_product_id', 'paper_type', 'cut_date', 'slitter', 'jumbo_lot'].forEach(f => {
          if (s[f] !== s._original[f]) {
            changes.push({ action: 'update', table: 'paper_scans', id: s.id,
                           field: f, old: s._original[f], new: s[f] });
          }
        });
      }
    }

    // 4. Write all audit logs
    const ip = await getClientIP();
    const auditInserts = changes.map(c => ({
      ip_address: ip,
      table_name: c.table,
      record_id: c.id,
      action: c.action,
      field_name: c.field,
      old_value: c.old == null ? null : String(c.old),
      new_value: c.new == null ? null : String(c.new),
      batch_id: batchId,
      note: null
    }));
    if (auditInserts.length > 0) {
      await supabase.from('edit_audit_logs').insert(auditInserts);
    }

    alert(`✓ บันทึกเรียบร้อย (${changes.length} การเปลี่ยนแปลง)`);
    _currentEditor = null;
    document.getElementById('edit-editor-panel').style.display = 'none';
    document.getElementById('edit-list-panel').style.display = 'block';
    loadEditList();
  } catch (err) {
    console.error(err);
    alert('บันทึกไม่สำเร็จ: ' + err.message);
    saveBtn.disabled = false;
    saveBtn.textContent = '💾 บันทึกการแก้ไข';
  }
}

// ==== Hook handlers ====
document.getElementById('btn-e-search').addEventListener('click', loadEditList);
document.getElementById('e-show-voided').addEventListener('change', loadEditList);

// ==================== VIEW 6: STATS ====================

async function loadStats() {
  const from = document.getElementById('s-from').value;
  const to = document.getElementById('s-to').value;

  if (!from || !to) {
    alert('กรุณาเลือกช่วงวันที่');
    return;
  }

  const container = document.getElementById('s-result');
  container.innerHTML = '<div class="loading"><div class="spinner-small"></div><div style="margin-top:10px;">กำลังคำนวณสถิติ...</div></div>';

  try {
    // Load all scans in date range (via v_scan_details view — voided excluded)
    const { data: scans, error } = await supabase
      .from('v_scan_details')
      .select('id, barcode_raw, slitter, barcode_valid, barcode_warnings, production_date, machine_name, jumbo_lot, paper_type, scanned_at, batch_id')
      .gte('production_date', from)
      .lte('production_date', to)
      .order('scanned_at', { ascending: false });
    if (error) throw error;

    if (!scans || scans.length === 0) {
      container.innerHTML = '<div class="empty"><span class="emoji">📭</span><div class="empty-title">ไม่พบข้อมูลในช่วงเวลานี้</div></div>';
      return;
    }

    renderStats(scans, { from, to });
  } catch (err) {
    console.error(err);
    container.innerHTML = `<div class="empty"><span class="emoji">⚠️</span><div class="empty-title">โหลดสถิติไม่สำเร็จ</div><div>${escapeHtml(err.message)}</div></div>`;
  }
}

function renderStats(scans, params) {
  const container = document.getElementById('s-result');

  const total = scans.length;
  const invalid = scans.filter(s => s.barcode_valid === false);
  const errorCount = invalid.length;
  const errorRate = total > 0 ? (errorCount / total * 100) : 0;
  const uniqueSlitters = [...new Set(scans.map(s => s.slitter).filter(Boolean))].sort();
  const uniqueDays = new Set(scans.map(s => s.production_date)).size;

  // ===== 1. Summary cards =====
  let html = `<div class="stats-cards">
    <div class="stats-card">
      <div class="stats-card-label">ม้วนทั้งหมด</div>
      <div class="stats-card-value">${total.toLocaleString()}</div>
      <div class="stats-card-sub">ใน ${uniqueDays} วัน</div>
    </div>
    <div class="stats-card">
      <div class="stats-card-label">Error (ผิด format)</div>
      <div class="stats-card-value" style="color:var(--danger);">${errorCount.toLocaleString()}</div>
      <div class="stats-card-sub">${errorRate.toFixed(2)}% ของทั้งหมด</div>
    </div>
    <div class="stats-card">
      <div class="stats-card-label">Slitter ที่ใช้งาน</div>
      <div class="stats-card-value" style="color:var(--accent-2);">${uniqueSlitters.length}</div>
      <div class="stats-card-sub">เครื่อง</div>
    </div>
    <div class="stats-card">
      <div class="stats-card-label">ค่าเฉลี่ยต่อวัน</div>
      <div class="stats-card-value" style="color:var(--accent);">${Math.round(total / uniqueDays).toLocaleString()}</div>
      <div class="stats-card-sub">ม้วน/วัน</div>
    </div>
  </div>`;

  // ===== 2. Error rate by Slitter =====
  const slitterStats = {};
  scans.forEach(s => {
    const key = s.slitter || '(ไม่ระบุ)';
    if (!slitterStats[key]) slitterStats[key] = { total: 0, errors: 0 };
    slitterStats[key].total++;
    if (s.barcode_valid === false) slitterStats[key].errors++;
  });

  const sortedSlitters = Object.entries(slitterStats)
    .map(([k, v]) => ({
      slitter: k,
      total: v.total,
      errors: v.errors,
      rate: v.total > 0 ? (v.errors / v.total * 100) : 0
    }))
    .sort((a, b) => b.rate - a.rate);  // เรียง error rate สูง → ต่ำ

  const maxRate = Math.max(...sortedSlitters.map(s => s.rate), 1);

  html += `<div style="background:var(--panel);border:1.5px solid var(--border);border-radius:12px;padding:20px;margin-bottom:16px;">
    <h3 style="font-size:17px;font-weight:800;margin-bottom:6px;">🎯 Error Rate ต่อ Slitter</h3>
    <p style="font-size:13px;color:var(--text-dim);margin-bottom:16px;">พนักงาน slitter ที่มี error % สูง = ควรฝึกเพิ่ม</p>`;

  if (sortedSlitters.length === 0) {
    html += '<div style="color:var(--text-dim);text-align:center;padding:20px;">ไม่มีข้อมูล slitter</div>';
  } else {
    sortedSlitters.forEach(s => {
      const fillWidth = Math.max(s.rate / maxRate * 100, 2);
      const rateClass = s.rate === 0 ? 'low' : (s.rate < 2 ? 'low' : (s.rate < 5 ? 'med' : 'high'));
      const displayName = s.slitter === '(ไม่ระบุ)' ? s.slitter : `Slitter ${s.slitter}`;
      html += `<div class="bar-row">
        <div class="bar-label">${escapeHtml(displayName)}</div>
        <div class="bar-track">
          <div class="bar-fill ${rateClass}" style="width:${fillWidth}%;">
            ${s.rate.toFixed(2)}%
          </div>
        </div>
        <div class="bar-numbers">${s.errors}/${s.total} ม้วน</div>
      </div>`;
    });
  }
  html += '</div>';

  // ===== 3. Trend line (daily error rate) =====
  const byDay = {};
  scans.forEach(s => {
    const d = s.production_date;
    if (!byDay[d]) byDay[d] = { total: 0, errors: 0 };
    byDay[d].total++;
    if (s.barcode_valid === false) byDay[d].errors++;
  });

  const sortedDays = Object.entries(byDay)
    .map(([d, v]) => ({ date: d, total: v.total, errors: v.errors, rate: v.total > 0 ? v.errors / v.total * 100 : 0 }))
    .sort((a, b) => a.date.localeCompare(b.date));

  if (sortedDays.length > 1) {
    const maxDayRate = Math.max(...sortedDays.map(d => d.rate), 1);
    const w = 800, h = 200, pad = 40;
    const chartW = w - pad * 2;
    const chartH = h - pad * 2;
    const xStep = sortedDays.length > 1 ? chartW / (sortedDays.length - 1) : 0;

    const points = sortedDays.map((d, i) => {
      const x = pad + i * xStep;
      const y = pad + chartH - (d.rate / maxDayRate * chartH);
      return { x, y, ...d };
    });

    const pathStr = points.map((p, i) => `${i === 0 ? 'M' : 'L'} ${p.x.toFixed(1)} ${p.y.toFixed(1)}`).join(' ');
    const circles = points.map(p =>
      `<circle cx="${p.x.toFixed(1)}" cy="${p.y.toFixed(1)}" r="4" fill="#c2410c">
        <title>${p.date}: ${p.errors}/${p.total} (${p.rate.toFixed(2)}%)</title>
      </circle>`
    ).join('');

    // X-axis labels (show every Nth if too many)
    const labelStep = Math.max(1, Math.ceil(sortedDays.length / 10));
    const xLabels = points.filter((_, i) => i % labelStep === 0).map(p =>
      `<text x="${p.x.toFixed(1)}" y="${h - 10}" font-size="10" fill="#64748b" text-anchor="middle" font-family="monospace">${p.date.slice(5)}</text>`
    ).join('');

    // Y-axis gridlines
    const yGrid = [0, 25, 50, 75, 100].map(pct => {
      const yVal = maxDayRate * pct / 100;
      const y = pad + chartH - (yVal / maxDayRate * chartH);
      return `<line x1="${pad}" y1="${y.toFixed(1)}" x2="${w - pad}" y2="${y.toFixed(1)}" stroke="#e5e7eb" stroke-dasharray="2,2"/>
              <text x="${pad - 6}" y="${(y+3).toFixed(1)}" font-size="10" fill="#94a3b8" text-anchor="end" font-family="monospace">${yVal.toFixed(1)}%</text>`;
    }).join('');

    html += `<div style="background:var(--panel);border:1.5px solid var(--border);border-radius:12px;padding:20px;margin-bottom:16px;">
      <h3 style="font-size:17px;font-weight:800;margin-bottom:6px;">📉 แนวโน้ม Error Rate รายวัน</h3>
      <p style="font-size:13px;color:var(--text-dim);margin-bottom:12px;">ถ้ามี spike วันไหน ไปดู batch ของวันนั้นได้</p>
      <div class="trend-chart">
        <svg class="trend-svg" viewBox="0 0 ${w} ${h}" preserveAspectRatio="xMidYMid meet">
          ${yGrid}
          <path d="${pathStr}" stroke="#c2410c" stroke-width="2" fill="none"/>
          ${circles}
          ${xLabels}
        </svg>
      </div>
    </div>`;
  }

  // ===== 4. Recent errors list =====
  html += `<div style="background:var(--panel);border:1.5px solid var(--border);border-radius:12px;padding:20px;">
    <h3 style="font-size:17px;font-weight:800;margin-bottom:6px;">📝 Error ล่าสุด (20 รายการ)</h3>
    <p style="font-size:13px;color:var(--text-dim);margin-bottom:12px;">คลิกเพื่อดูรายละเอียด batch</p>`;

  if (invalid.length === 0) {
    html += '<div style="color:var(--success);font-weight:700;text-align:center;padding:24px;">🎉 ไม่มี error ในช่วงนี้!</div>';
  } else {
    invalid.slice(0, 20).forEach((s, i) => {
      const dt = new Date(s.scanned_at).toLocaleString('th-TH', {
        day:'2-digit', month:'short', hour:'2-digit', minute:'2-digit'
      });
      html += `<div class="error-row" data-batch-id="${s.batch_id}">
        <div class="error-row-num">${i + 1}</div>
        <div class="error-row-info">
          <div class="error-row-barcode">${escapeHtml(s.barcode_raw || '')}</div>
          <div class="error-row-reason">⚠️ ${escapeHtml(s.barcode_warnings || 'ผิด format')}</div>
          <div class="error-row-meta">${dt} · ${escapeHtml(s.machine_name || '-')}</div>
        </div>
        <div class="error-row-slitter" title="Slitter">S-${escapeHtml(s.slitter || '?')}</div>
      </div>`;
    });
  }
  html += '</div>';

  container.innerHTML = html;

  // Click error row → open batch detail
  container.querySelectorAll('.error-row[data-batch-id]').forEach(el => {
    el.addEventListener('click', () => openBatchDetail(el.dataset.batchId));
  });
}

document.getElementById('btn-s-search').addEventListener('click', loadStats);
document.getElementById('btn-s-preset').addEventListener('click', () => {
  const today = new Date();
  const thirtyDaysAgo = new Date(today.getTime() - 30 * 24 * 60 * 60 * 1000);
  document.getElementById('s-from').valueAsDate = thirtyDaysAgo;
  document.getElementById('s-to').valueAsDate = today;
  loadStats();
});

// ==================== VIEW 4: ACCESS LOG ====================
let accessLogLoaded = false;
async function loadAccessLog() {
  const container = document.getElementById('access-result');
  container.innerHTML = '<div class="loading"><div class="spinner-small"></div><div style="margin-top:10px;">กำลังโหลด...</div></div>';

  try {
    const { data, error } = await supabase
      .from('dashboard_access_logs')
      .select('*')
      .order('accessed_at', { ascending: false })
      .limit(100);
    if (error) throw error;

    if (!data || data.length === 0) {
      container.innerHTML = '<div class="empty"><span class="emoji">📭</span><div class="empty-title">ยังไม่มีประวัติ</div></div>';
      document.getElementById('access-stats').style.display = 'none';
      return;
    }

    // Stats
    const total = data.length;
    const ok = data.filter(d => d.success).length;
    const fail = total - ok;
    const uniqueIPs = new Set(data.map(d => d.ip_address).filter(Boolean)).size;

    document.getElementById('ac-total').textContent = total;
    document.getElementById('ac-ok').textContent = ok;
    document.getElementById('ac-fail').textContent = fail;
    document.getElementById('ac-ips').textContent = uniqueIPs;
    document.getElementById('access-stats').style.display = 'grid';

    // Table
    let html = `<table class="log-table">
      <thead>
        <tr>
          <th>วันเวลา</th>
          <th>IP Address</th>
          <th>สถานะ</th>
          <th>Device</th>
          <th>หมายเหตุ</th>
        </tr>
      </thead>
      <tbody>`;

    data.forEach(log => {
      const d = new Date(log.accessed_at);
      const dateStr = d.toLocaleString('th-TH', {
        day: '2-digit', month: 'short', year: '2-digit',
        hour: '2-digit', minute: '2-digit', second: '2-digit'
      });
      // Detect device from user agent (simple)
      let device = 'Desktop';
      const ua = (log.user_agent || '').toLowerCase();
      if (ua.includes('mobile') || ua.includes('android') || ua.includes('iphone')) device = '📱 Mobile';
      else if (ua.includes('ipad') || ua.includes('tablet')) device = '📱 Tablet';
      else device = '💻 Desktop';

      html += `<tr>
        <td>${escapeHtml(dateStr)}</td>
        <td><strong>${escapeHtml(log.ip_address || '-')}</strong></td>
        <td>${log.success
          ? '<span class="log-success">✓ สำเร็จ</span>'
          : '<span class="log-fail">✗ ล้มเหลว</span>'}</td>
        <td>${device}</td>
        <td style="color:var(--text-dim);font-size:12px;">${escapeHtml(log.note || '-')}</td>
      </tr>`;
    });

    html += '</tbody></table>';
    container.innerHTML = html;
  } catch (err) {
    console.error(err);
    container.innerHTML = `<div class="empty"><span class="emoji">⚠️</span><div class="empty-title">โหลดไม่สำเร็จ</div><div>${escapeHtml(err.message)}</div></div>`;
  }
}

// ==================== INIT ====================
function initDashboard() {
  loadMaster();
}
// (initDashboard จะถูกเรียกหลัง login สำเร็จ)
